E:\software\job_assignments\BSA_Student_Feedback>pip install -e .
Defaulting to user installation because normal site-packages is not writeable
Obtaining file:///E:/software/job_assignments/BSA_Student_Feedback
  Installing build dependencies ... done
  Checking if build backend supports build_editable ... done
  Getting requirements to build editable ... done
  Preparing editable metadata (pyproject.toml) ... done
Building wheels for collected packages: course_eval_ai
  Building editable for course_eval_ai (pyproject.toml) ... done
  Created wheel for course_eval_ai: filename=course_eval_ai-0.0.0-0.editable-py3-none-any.whl size=1265 sha256=6b21a819dac79b3a7ec58d8a53a7128dce02b5b56cfc95cfdc447bbbb5aebbde
  Stored in directory: C:\Users\stain\AppData\Local\Temp\pip-ephem-wheel-cache-7qa1aiyg\wheels\46\f1\9c\9187bcd908ee83be7e79fc2c6599620fa2bd8622cce3ce93c6
Successfully built course_eval_ai
Installing collected packages: course_eval_ai
Successfully installed course_eval_ai-0.0.0




1. Commands to run: 
python -m streamlit run dashboard/streamlit_app.py

http://127.0.0.1:8000
http://127.0.0.1:8000/docs
http://127.0.0.1:8000/api/v1/health
http://127.0.0.1:8000/api/v1/courses/performance
http://127.0.0.1:8000/api/v1/instructors/performance
http://127.0.0.1:8000/api/v1/instructors/performance?min_response_count=1

FastAPI docs:      http://127.0.0.1:8000/docs
FastAPI health:    http://127.0.0.1:8000/api/v1/health
Streamlit app:     http://localhost:8501






E:\software\job_assignments\BSA_Student_Feedback>psql -h localhost -U postgres -d course_eval_ai -f database\views\vw_bronze_row_scores.sql
'psql' is not recognized as an internal or external command,
operable program or batch file.

E:\software\job_assignments\BSA_Student_Feedback>python pipelines\scripts\run_sql_views.py
Running: vw_bronze_row_scores.sql
Running: vw_course_performance.sql
Running: vw_instructor_performance.sql
Running: vw_department_performance.sql
SKIPPED: vw_college_performance.sql is empty
Running: vw_course_alerts.sql
All SQL views created successfully.

E:\software\job_assignments\BSA_Student_Feedback>python pipelines\scripts\test_sql_views.py

================================================================================
Testing: vw_bronze_row_scores
              Instructor_alias  ... answered_course_question_count
0  instructor_7f829abf0e2f8bc2  ...                              5
1  instructor_7f829abf0e2f8bc2  ...                              5
2  instructor_7f829abf0e2f8bc2  ...                              5
3  instructor_7f829abf0e2f8bc2  ...                              5
4  instructor_7f829abf0e2f8bc2  ...                              5

[5 rows x 26 columns]

================================================================================
Testing: vw_course_performance
  CourseIdentifier                            CourseTitle  ... instructor_vs_department_delta          risk_status
0       CAN 207 31                     Comparative Health  ...                          -0.05                   OK
1       CAN 215 31                  Experimental Business  ...                           0.05       LOW CONFIDENCE
2       CAN 222 31                 Methods in Linguistics  ...                           0.05  INSUFFICIENT SAMPLE
3       EMPL 230 1   Experimental Art in the Modern World  ...                           0.49       LOW CONFIDENCE
4       EMPL 233 1  Principles of History across Cultures  ...                          -0.18                   OK

[5 rows x 21 columns]

================================================================================
Testing: vw_instructor_performance
              Instructor_alias                Department  ... instructor_percentile_in_department     risk_status
0  instructor_8307790eb63c20a8  Analytical Communication  ...                                 0.0              OK
1  instructor_7f829abf0e2f8bc2           Clinical Policy  ...                                 0.0          REVIEW
2  instructor_64c28bc474cbc9fd           Clinical Policy  ...                                 0.5              OK
3  instructor_140930cb0b9bbb25           Clinical Policy  ...                                 1.0  LOW CONFIDENCE
4  instructor_bf1ebce518ccef08     Environmental Biology  ...                                 0.0              OK

[5 rows x 18 columns]

================================================================================
Testing: vw_department_performance
                 Department                               College  ...  instructor_rating_median  risk_status
0  Analytical Communication               College of Liberal Arts  ...                      4.43           OK
1           Clinical Policy               College of Liberal Arts  ...                      3.57           OK
2     Environmental Biology               College of Liberal Arts  ...                      4.00           OK
3    Environmental Practice          School of Health and Society  ...                      5.00           OK
4  Experimental Mathematics  College of Engineering and Computing  ...                      4.86           OK

[5 rows x 13 columns]

================================================================================
Testing: vw_course_alerts
  CourseIdentifier                               CourseTitle  ...          risk_status alert_priority
0       LOSE 124 1                      Principles of Policy  ...  INSUFFICIENT SAMPLE              5
1       CAN 222 31                    Methods in Linguistics  ...  INSUFFICIENT SAMPLE              5
2     MOME 658 811  Principles of Economics and Applications  ...  INSUFFICIENT SAMPLE              5
3       EMPL 230 1      Experimental Art in the Modern World  ...       LOW CONFIDENCE              2
4     WHOS 133 810                      Principles of Ethics  ...       LOW CONFIDENCE              2

[5 rows x 18 columns]

E:\software\job_assignments\BSA_Student_Feedback>



Test queries

Run these in pgAdmin:

SELECT *
FROM vw_bronze_row_scores
LIMIT 10;


SELECT *
FROM vw_course_performance
ORDER BY avg_course_rating ASC
LIMIT 20;


SELECT *
FROM vw_instructor_performance
ORDER BY avg_instructor_rating ASC
LIMIT 20;


SELECT *
FROM vw_department_performance
ORDER BY avg_course_rating ASC;


SELECT *
FROM vw_course_alerts;