BSA_Student_Feedback/
│
├── README.md
├── .env
├── .gitignore
├── pyproject.toml
├── requirements.txt
├── docker-compose.yml
│
├── config/
│   ├── app_config.yaml
│   ├── database_config.yaml
│   ├── pipeline_config.yaml
│   ├── model_config.yaml
│   └── logging_config.yaml
│
├── data/
│   ├── raw/
│   │   ├── incoming/
│   │   ├── archived/
│   │   └── rejected/
│   │
│   ├── bronze/
│   │   ├── cleaned/
│   │   ├── identity_protected/
│   │   ├── comment_queue/
│   │   └── exports/
│   │       └── bronze_cleaned_data.csv
│   │
│   ├── silver/
│   │   ├── structured_metrics/
│   │   ├── comment_insights/
│   │   ├── embeddings/
│   │   └── rag_chunks/
│   │
│   ├── gold/
│   │   ├── kpi_tables/
│   │   ├── dashboard_tables/
│   │   ├── api_outputs/
│   │   └── exports/
│   │
│   ├── AI_DEV_SAMPLE_COURSE_EVALS_SANITIZED.csv
│   │
│   └── samples/
│       ├── sample_course_evals.csv
│       └── sample_course_evals.xlsx
│
├── database/
│   ├── schemas/
│   │   ├── raw_schema.sql
│   │   ├── bronze_schema.sql
│   │   ├── silver_schema.sql
│   │   ├── gold_schema.sql
│   │   └── security_schema.sql, silver_star_schema.sql
│   │
│   ├── migrations/
│   │   ├── 001_create_raw_tables.sql
│   │   ├── 002_create_bronze_tables.sql
│   │   ├── 003_create_silver_tables.sql
│   │   ├── 004_create_gold_tables.sql
│   │   └── 005_create_indexes.sql, load_silver_star_from_bronze.sql
│   │
│   ├── views/
│   │   ├── vw_course_performance.sql
│   │   ├── vw_instructor_performance.sql
│   │   ├── vw_department_performance.sql
│   │   ├── vw_college_performance.sql
│   │   └── vw_course_alerts.sql
│   │
│   ├── kpis/
│   │   ├── kpi_course_rating.sql
│   │   ├── kpi_instructor_rating.sql
│   │   ├── kpi_response_count.sql
│   │   ├── kpi_rating_gap.sql
│   │   └── kpi_low_score_alerts.sql
│   │
│   └── seeds/
│       ├── dim_question_seed.csv
│       ├── dim_session_seed.csv
│       └── delivery_code_seed.csv
│
├── pipelines/
│   ├── mage/
│   │   ├── raw_ingestion/
│   │   │   ├── load_raw_evaluation_file.py
│   │   │   └── export_raw_uploaded_files.py
│   │   │
│   │   ├── bronze/
│   │   │   ├── validate_clean_bronze_data.py
│   │   │   ├── create_instructor_aliases.py
│   │   │   ├── preprocess_comment_privacy.py
│   │   │   ├── create_bronze_cleaned_data.py
│   │   │   └── export_bronze_cleaned_data.py
│   │   │
│   │   ├── silver/
│   │   │   ├── create_structured_metrics_input.py
│   │   │   ├── generate_comment_insights.py
│   │   │   ├── create_rag_chunks.py
│   │   │   └── generate_embeddings.py
│   │   │
│   │   ├── gold/
│   │   │   ├── refresh_gold_course_performance.py
│   │   │   ├── refresh_gold_instructor_performance.py
│   │   │   ├── refresh_gold_department_performance.py
│   │   │   ├── refresh_gold_alerts.py
│   │   │   └── refresh_gold_kpis.py
│   │   │
│   │   └── monitoring/
│   │       ├── pipeline_audit_log.py
│   │       ├── quality_report.py
│   │       └── failure_alerts.py
│   │
│   └── scripts/
│       ├── run_full_pipeline.py
│       ├── run_bronze_only.py
│       ├── run_gold_refresh.py
│       └── export_bronze_csv.py, run_sql_views.py, test_sql_views.py
│
├── src/
│   ├── course_eval_ai/
│   │   ├── __init__.py
│   │   │
│   │   ├── core/
│   │   │   ├── settings.py
│   │   │   ├── database.py
│   │   │   ├── logging.py
│   │   │   └── exceptions.py
│   │   │
│   │   ├── ingestion/
│   │   │   ├── csv_loader.py
│   │   │   ├── excel_loader.py
│   │   │   └── source_file_registry.py
│   │   │
│   │   ├── validation/
│   │   │   ├── schema_validator.py
│   │   │   ├── rating_validator.py
│   │   │   ├── missing_value_validator.py
│   │   │   └── quality_rules.py
│   │   │
│   │   ├── privacy/
│   │   │   ├── instructor_aliasing.py
│   │   │   ├── pii_detection.py
│   │   │   ├── comment_redaction.py
│   │   │   └── access_control.py
│   │   │
│   │   ├── analytics/
│   │   │   ├── course_metrics.py
│   │   │   ├── instructor_metrics.py
│   │   │   ├── department_metrics.py
│   │   │   ├── college_metrics.py
│   │   │   └── alert_rules.py
│   │   │
│   │   ├── rag/
│   │   │   ├── chunking.py
│   │   │   ├── embeddings.py
│   │   │   ├── vector_store.py
│   │   │   ├── retriever.py
│   │   │   └── rag_chain.py
│   │   │
│   │   ├── agents/
│   │   │   ├── text_to_sql_agent.py
│   │   │   ├── rag_agent.py
│   │   │   ├── insight_agent.py
│   │   │   ├── recommendation_agent.py
│   │   │   └── guardrails.py
│   │   │
│   │   ├── skills/
│   │   │   ├── query_course_performance.py
│   │   │   ├── query_instructor_performance.py
│   │   │   ├── summarize_comments.py
│   │   │   ├── detect_course_alerts.py
│   │   │   └── generate_admin_recommendations.py
│   │   │
│   │   └── utils/
│   │       ├── file_utils.py
│   │       ├── sql_utils.py
│   │       ├── date_utils.py
│   │       └── dataframe_utils.py
│
├── api/
│   ├── main.py
│   ├── dependencies.py
│   ├── routers/
│   │   ├── health.py
│   │   ├── courses.py
│   │   ├── instructors.py
│   │   ├── departments.py
│   │   ├── colleges.py
│   │   ├── alerts.py
│   │   ├── text_to_sql.py
│   │   └── rag.py
│   │
│   ├── schemas/
│   │   ├── course_schema.py
│   │   ├── instructor_schema.py
│   │   ├── department_schema.py
│   │   ├── alert_schema.py
│   │   └── rag_schema.py
│   │
│   └── services/
│       ├── course_service.py
│       ├── instructor_service.py
│       ├── department_service.py
│       ├── alert_service.py
│       └── rag_service.py
│
├── dashboard/
│   ├── streamlit_app.py
│   ├── pages/
│   │   ├── 1_Executive_Summary.py
│   │   ├── 2_Course_Performance.py
│   │   ├── 3_Instructor_Performance.py
│   │   ├── 4_Department_Insights.py
│   │   ├── 5_Alerts.py
│   │   └── 6_Ask_AI.py
│   │
│   ├── components/
│   │   ├── filters.py
│   │   ├── charts.py
│   │   ├── kpi_cards.py
│   │   └── tables.py
│   │
│   └── assets/
│       ├── logo.png
│       └── styles.css
│
├── models/
│   ├── prompts/
│   │   ├── text_to_sql_prompt.txt
│   │   ├── rag_prompt.txt
│   │   ├── comment_summary_prompt.txt
│   │   └── recommendation_prompt.txt
│   │
│   ├── evaluation/
│   │   ├── text_to_sql_test_questions.csv
│   │   ├── rag_eval_questions.csv
│   │   └── expected_outputs.csv
│   │
│   └── model_cards/
│       ├── text_to_sql_model_card.md
│       └── embedding_model_card.md
│
├── tests/
│   ├── unit/
│   │   ├── test_schema_validator.py
│   │   ├── test_rating_validator.py
│   │   ├── test_instructor_aliasing.py
│   │   ├── test_sql_guardrails.py
│   │   └── test_kpi_calculations.py
│   │
│   ├── integration/
│   │   ├── test_bronze_pipeline.py
│   │   ├── test_gold_views.py
│   │   ├── test_api_endpoints.py
│   │   └── test_text_to_sql_agent.py
│   │
│   └── fixtures/
│       ├── sample_valid_evals.csv
│       ├── sample_invalid_evals.csv
│       └── sample_comments_with_pii.csv
│
├── notebooks/
│   ├── 01_data_exploration.ipynb
│   ├── 02_missing_values_analysis.ipynb
│   ├── 03_rating_distribution_analysis.ipynb
│   ├── 04_comment_ai_experiments.ipynb
│   └── 05_dashboard_prototype.ipynb
│
├── docs/
│   ├── architecture.md
│   ├── data_dictionary.md
│   ├── data_model.md
│   ├── pipeline_design.md
│   ├── api_documentation.md
│   ├── privacy_and_security.md
│   ├── ai_governance.md
│   ├── dashboard_design.md
│   ├── metric_definitions.md
│   └── deployment_guide.md
│
├── infra/
│   ├── docker/
│   │   ├── Dockerfile.api
│   │   ├── Dockerfile.dashboard
│   │   └── Dockerfile.mage
│   │
│   ├── postgres/
│   │   ├── init.sql
│   │   └── indexes.sql
│   │
│   ├── vector_db/
│   │   ├── chroma_config.yaml
│   │   └── pgvector_config.sql
│   │
│   ├── cloud/
│   │   ├── terraform/
│   │   └── kubernetes/
│   │
│   └── infra.md
│
├── Versions/
│   ├── v1.0 - MVP/
│   ├── v1.1 - SQL_TO_Text_agent/
│   └── reports/
│
└── archive/
    ├── interview_notes/
    ├── installations/
    └── deprecated_scripts/





# Rules
api/        = FastAPI only
dashboard/  = Streamlit only
src/        = reusable business logic
pipelines/  = Mage orchestration
database/   = SQL truth
data/       = raw/bronze/silver/gold files
models/     = prompts and AI evaluation