import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
import plotly.express as px
from dashboard.components.floating_ai import floating_dashboard_ai


# -------------------------------------------------
# Page setup
# -------------------------------------------------
st.set_page_config(
    page_title="Executive Summary",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .block-container {
        padding-top: 3.5rem;
    }

    .main-title {
        font-size: 34px;
        font-weight: 800;
        color: #172033;
        margin-bottom: 0.2rem;
    }

    .subtitle {
        color: #667085;
        font-size: 15px;
        margin-bottom: 1.3rem;
    }

    .section-title {
        font-size: 22px;
        font-weight: 800;
        color: #111827;
        margin-top: 1.2rem;
        margin-bottom: 0.5rem;
    }

    .section-note {
        color: #667085;
        font-size: 14px;
        margin-bottom: 1rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# -------------------------------------------------
# Database
# -------------------------------------------------
engine = create_engine(
    "postgresql://postgres:admin@localhost:5432/course_eval_ai"
)


@st.cache_data
def load_data():
    df = pd.read_sql("SELECT * FROM bronze_cleaned_data", engine)

    try:
        instructor_map = pd.read_sql(
            """
            SELECT
                instructor_alias AS "Instructor_alias",
                "InstructorName" AS "ProfessorName"
            FROM bronze_instructor_alias_map
            """,
            engine,
        )

        df = df.merge(
            instructor_map,
            on="Instructor_alias",
            how="left",
        )

        df["ProfessorDisplay"] = df["ProfessorName"].fillna(df["Instructor_alias"])

    except Exception:
        df["ProfessorDisplay"] = df["Instructor_alias"]

    return df


df = load_data()


# -------------------------------------------------
# Rating setup
# -------------------------------------------------
instructor_cols = ["i1", "i2", "i3", "i4", "i5", "i6", "i7"]
course_cols = ["c1", "c2", "c3", "c4", "c5"]

df["avg_professor_rating"] = df[instructor_cols].mean(axis=1, skipna=True)
df["avg_course_rating"] = df[course_cols].mean(axis=1, skipna=True)

df["rating_gap"] = (
    df["avg_professor_rating"] - df["avg_course_rating"]
).round(2)


# -------------------------------------------------
# Sidebar filters
# -------------------------------------------------
st.sidebar.title("Executive Filters")

college_options = sorted(df["College"].dropna().unique())
department_options = sorted(df["Department"].dropna().unique())
delivery_options = sorted(df["DeliveryCode"].dropna().unique())

selected_colleges = st.sidebar.multiselect(
    "College",
    college_options,
    default=college_options,
)

selected_departments = st.sidebar.multiselect(
    "Department",
    department_options,
    default=department_options,
)

selected_delivery = st.sidebar.multiselect(
    "Delivery Mode",
    delivery_options,
    default=delivery_options,
)

min_responses = st.sidebar.slider(
    "Minimum response count",
    min_value=1,
    max_value=30,
    value=3,
)


filtered = df[
    df["College"].isin(selected_colleges)
    & df["Department"].isin(selected_departments)
    & df["DeliveryCode"].isin(selected_delivery)
].copy()

if filtered.empty:
    st.warning("No data found for selected filters.")
    st.stop()


# -------------------------------------------------
# Aggregations
# -------------------------------------------------
course_summary = (
    filtered.groupby(
        [
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
        ]
    )
    .agg(
        avg_course_rating=("avg_course_rating", "mean"),
        avg_professor_rating=("avg_professor_rating", "mean"),
        response_count=("CourseIdentifier", "count"),
        professor_count=("ProfessorDisplay", "nunique"),
    )
    .reset_index()
)

course_summary["avg_course_rating"] = course_summary["avg_course_rating"].round(2)
course_summary["avg_professor_rating"] = course_summary["avg_professor_rating"].round(2)
course_summary["rating_gap"] = (
    course_summary["avg_professor_rating"] - course_summary["avg_course_rating"]
).round(2)


professor_summary = (
    filtered.groupby(
        [
            "ProfessorDisplay",
            "Instructor_alias",
            "Department",
            "College",
        ]
    )
    .agg(
        avg_professor_rating=("avg_professor_rating", "mean"),
        avg_course_rating=("avg_course_rating", "mean"),
        response_count=("ProfessorDisplay", "count"),
        course_count=("CourseIdentifier", "nunique"),
    )
    .reset_index()
)

professor_summary["avg_professor_rating"] = professor_summary["avg_professor_rating"].round(2)
professor_summary["avg_course_rating"] = professor_summary["avg_course_rating"].round(2)
professor_summary["rating_gap"] = (
    professor_summary["avg_professor_rating"] - professor_summary["avg_course_rating"]
).round(2)


professor_course = (
    filtered.groupby(
        [
            "ProfessorDisplay",
            "Instructor_alias",
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
        ]
    )
    .agg(
        professor_rating=("avg_professor_rating", "mean"),
        course_rating=("avg_course_rating", "mean"),
        response_count=("CourseIdentifier", "count"),
    )
    .reset_index()
)

professor_course["professor_rating"] = professor_course["professor_rating"].round(2)
professor_course["course_rating"] = professor_course["course_rating"].round(2)
professor_course["rating_gap"] = (
    professor_course["professor_rating"] - professor_course["course_rating"]
).round(2)


department_summary = (
    filtered.groupby(["Department", "College"])
    .agg(
        avg_course_rating=("avg_course_rating", "mean"),
        avg_professor_rating=("avg_professor_rating", "mean"),
        response_count=("Department", "count"),
        course_count=("CourseIdentifier", "nunique"),
        professor_count=("ProfessorDisplay", "nunique"),
    )
    .reset_index()
)

department_summary["avg_course_rating"] = department_summary["avg_course_rating"].round(2)
department_summary["avg_professor_rating"] = department_summary["avg_professor_rating"].round(2)


# -------------------------------------------------
# Risk labels
# -------------------------------------------------
professor_course["risk_status"] = professor_course.apply(
    lambda row: "Low sample"
    if row["response_count"] < min_responses
    else "Review"
    if row["course_rating"] < 3.5 or row["professor_rating"] < 3.5
    else "Monitor"
    if row["course_rating"] < 4.0 or row["professor_rating"] < 4.0
    else "Strong",
    axis=1,
)


# -------------------------------------------------
# Title
# -------------------------------------------------
st.markdown(
    """
    <div class="main-title">Executive Summary</div>
    <div class="subtitle">
    High-level insight view for curriculum health, professor-course fit, and review priorities.
    </div>
    """,
    unsafe_allow_html=True,
)


# -------------------------------------------------
# KPI row
# -------------------------------------------------
avg_course_rating = round(filtered["avg_course_rating"].mean(), 2)
avg_professor_rating = round(filtered["avg_professor_rating"].mean(), 2)
total_evaluations = len(filtered)
total_courses = filtered["CourseIdentifier"].nunique()
total_professors = filtered["ProfessorDisplay"].nunique()

review_items = professor_course[
    professor_course["risk_status"].isin(["Review", "Low sample"])
].shape[0]

k1, k2, k3, k4, k5, k6 = st.columns(6)

k1.metric("Avg Course Rating", avg_course_rating)
k2.metric("Avg Professor Rating", avg_professor_rating)
k3.metric("Evaluations", total_evaluations)
k4.metric("Courses", total_courses)
k5.metric("Professors", total_professors)
k6.metric("Review Items", review_items)

st.divider()


# -------------------------------------------------
# Compact charts
# -------------------------------------------------
left, right = st.columns(2)

with left:
    st.markdown('<div class="section-title">Courses Needing Review</div>', unsafe_allow_html=True)

    low_courses = (
        course_summary[course_summary["response_count"] >= min_responses]
        .sort_values(["avg_course_rating", "response_count"], ascending=[True, False])
        .head(8)
    )

    fig = px.bar(
        low_courses,
        x="avg_course_rating",
        y="CourseIdentifier",
        orientation="h",
        hover_data=[
            "CourseTitle",
            "Department",
            "College",
            "response_count",
            "professor_count",
        ],
    )

    fig.update_layout(
        height=320,
        margin=dict(l=10, r=10, t=20, b=10),
        yaxis={"categoryorder": "total ascending"},
        showlegend=False,
    )

    st.plotly_chart(fig, use_container_width=True)

with right:
    st.markdown('<div class="section-title">Professors Needing Review</div>', unsafe_allow_html=True)

    low_professors = (
        professor_summary[professor_summary["response_count"] >= min_responses]
        .sort_values(["avg_professor_rating", "response_count"], ascending=[True, False])
        .head(8)
    )

    fig = px.bar(
        low_professors,
        x="avg_professor_rating",
        y="ProfessorDisplay",
        orientation="h",
        hover_data=[
            "Department",
            "College",
            "response_count",
            "course_count",
        ],
    )

    fig.update_layout(
        height=320,
        margin=dict(l=10, r=10, t=20, b=10),
        yaxis={"categoryorder": "total ascending"},
        showlegend=False,
    )

    st.plotly_chart(fig, use_container_width=True)

st.divider()


# -------------------------------------------------
# Decision tables
# -------------------------------------------------
t1, t2 = st.columns(2)

with t1:
    st.markdown('<div class="section-title">Curriculum Review Candidates</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="section-note">Courses where course design may need review.</div>',
        unsafe_allow_html=True,
    )

    curriculum_table = (
        course_summary[course_summary["response_count"] >= min_responses]
        .sort_values(["avg_course_rating", "rating_gap"], ascending=[True, False])
        .head(10)
    )

    st.dataframe(
        curriculum_table[
            [
                "CourseIdentifier",
                "CourseTitle",
                "Department",
                "College",
                "avg_course_rating",
                "avg_professor_rating",
                "rating_gap",
                "response_count",
            ]
        ],
        use_container_width=True,
        height=310,
    )

with t2:
    st.markdown('<div class="section-title">Professor-Course Fit Issues</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="section-note">Places where professor and course ratings suggest a possible fit issue.</div>',
        unsafe_allow_html=True,
    )

    fit_table = (
        professor_course[professor_course["response_count"] >= min_responses]
        .sort_values(["course_rating", "professor_rating"], ascending=[True, True])
        .head(10)
    )

    st.dataframe(
        fit_table[
            [
                "ProfessorDisplay",
                "CourseIdentifier",
                "CourseTitle",
                "professor_rating",
                "course_rating",
                "rating_gap",
                "response_count",
                "risk_status",
            ]
        ],
        use_container_width=True,
        height=310,
    )

st.divider()


# -------------------------------------------------
# Department summary
# -------------------------------------------------
st.markdown('<div class="section-title">Department-Level Summary</div>', unsafe_allow_html=True)

department_table = (
    department_summary
    .sort_values(["avg_course_rating", "response_count"], ascending=[True, False])
    .head(12)
)

st.dataframe(
    department_table[
        [
            "Department",
            "College",
            "avg_course_rating",
            "avg_professor_rating",
            "response_count",
            "course_count",
            "professor_count",
        ]
    ],
    use_container_width=True,
    height=320,
)



# -------------------------------------------------
# Floating AI Assistant
# -------------------------------------------------
kpi_context = {
    "avg_course_rating": avg_course_rating,
    "avg_professor_rating": avg_professor_rating,
    "total_evaluations": total_evaluations,
    "total_courses": total_courses,
    "total_professors": total_professors,
    "review_items": review_items,
    "min_responses": min_responses,
}

floating_dashboard_ai(
    page_name="Executive Summary",
    context_blocks={
        "KPIs": kpi_context,
        "Curriculum Review Candidates": curriculum_table,
        "Professor-Course Fit Issues": fit_table,
        "Department Summary": department_table,
        "Course Summary": course_summary,
        "Professor Summary": professor_summary,
    },
)