import streamlit as st

from course_eval_ai.agents.text_to_sql_agent import ask_database
from dashboard.components.floating_ai import floating_dashboard_ai

st.set_page_config(
    page_title="Ask AI",
    layout="wide"
)

st.title("Ask the Course Evaluation Database")

st.caption(
    "Gemini generates SQL against the privacy-safe bronze_cleaned_data table only."
)

examples = [
    "Which professor aliases have the lowest instructor ratings?",
    "Which courses have the lowest course ratings?",
    "Which courses have the biggest gap between instructor rating and course rating?",
    "Show average course rating by department.",
    "Show average professor rating by college.",
    "Which course has the most evaluations?",
]

example = st.selectbox("Example questions", [""] + examples)

question = st.text_input(
    "Ask a question",
    value=example,
    placeholder="Example: Which course has the lowest rating?",
)

if st.button("Ask Database"):
    if question.strip():
        try:
            sql, result_df = ask_database(question)

            st.subheader("Generated SQL")
            st.code(sql, language="sql")

            st.subheader("Result")
            st.dataframe(result_df, use_container_width=True)

        except Exception as e:
            st.error(str(e))
    else:
        st.warning("Type a question first.")