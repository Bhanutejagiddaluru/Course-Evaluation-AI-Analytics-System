import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
import plotly.express as px
from dashboard.components.floating_ai import floating_dashboard_ai


# -------------------------------------------------
# Page setup
# -------------------------------------------------
st.set_page_config(
    page_title="Alerts",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .block-container {
        padding-top: 5rem;
    }

    .main-title {
        font-size: 34px;
        font-weight: 800;
        color: #172033;
        margin-bottom: 0.2rem;
    }

    .subtitle {
        color: #667085;
        font-size: 15px;
        margin-bottom: 1.3rem;
    }

    .section-title {
        font-size: 22px;
        font-weight: 800;
        color: #111827;
        margin-top: 1.2rem;
        margin-bottom: 0.5rem;
    }

    .section-note {
        color: #667085;
        font-size: 14px;
        margin-bottom: 1rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# -------------------------------------------------
# Database
# -------------------------------------------------
engine = create_engine(
    "postgresql://postgres:admin@localhost:5432/course_eval_ai"
)


@st.cache_data
def load_data():
    df = pd.read_sql("SELECT * FROM bronze_cleaned_data", engine)

    try:
        instructor_map = pd.read_sql(
            """
            SELECT
                instructor_alias AS "Instructor_alias",
                "InstructorName" AS "ProfessorName"
            FROM bronze_instructor_alias_map
            """,
            engine,
        )

        df = df.merge(
            instructor_map,
            on="Instructor_alias",
            how="left",
        )

        df["ProfessorDisplay"] = df["ProfessorName"].fillna(df["Instructor_alias"])

    except Exception:
        df["ProfessorDisplay"] = df["Instructor_alias"]

    return df


df = load_data()


# -------------------------------------------------
# Ratings
# -------------------------------------------------
instructor_cols = ["i1", "i2", "i3", "i4", "i5", "i6", "i7"]
course_cols = ["c1", "c2", "c3", "c4", "c5"]

df["avg_professor_rating"] = df[instructor_cols].mean(axis=1, skipna=True)
df["avg_course_rating"] = df[course_cols].mean(axis=1, skipna=True)

df["rating_gap"] = (
    df["avg_professor_rating"] - df["avg_course_rating"]
).round(2)


# -------------------------------------------------
# Sidebar filters
# -------------------------------------------------
st.sidebar.title("Alert Filters")

college_options = sorted(df["College"].dropna().unique())
department_options = sorted(df["Department"].dropna().unique())
delivery_options = sorted(df["DeliveryCode"].dropna().unique())

selected_colleges = st.sidebar.multiselect(
    "College",
    college_options,
    default=college_options,
)

selected_departments = st.sidebar.multiselect(
    "Department",
    department_options,
    default=department_options,
)

selected_delivery = st.sidebar.multiselect(
    "Delivery Mode",
    delivery_options,
    default=delivery_options,
)

min_responses = st.sidebar.slider(
    "Minimum response count",
    min_value=1,
    max_value=30,
    value=3,
)

review_threshold = st.sidebar.slider(
    "Review threshold",
    min_value=1.0,
    max_value=5.0,
    value=3.5,
    step=0.1,
)

gap_threshold = st.sidebar.slider(
    "Rating gap threshold",
    min_value=0.1,
    max_value=2.0,
    value=0.75,
    step=0.05,
)


filtered = df[
    df["College"].isin(selected_colleges)
    & df["Department"].isin(selected_departments)
    & df["DeliveryCode"].isin(selected_delivery)
].copy()

if filtered.empty:
    st.warning("No data found for selected filters.")
    st.stop()


# -------------------------------------------------
# Aggregations
# -------------------------------------------------
course_summary = (
    filtered.groupby(
        [
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
        ]
    )
    .agg(
        avg_course_rating=("avg_course_rating", "mean"),
        avg_professor_rating=("avg_professor_rating", "mean"),
        response_count=("CourseIdentifier", "count"),
        professor_count=("ProfessorDisplay", "nunique"),
    )
    .reset_index()
)

course_summary["avg_course_rating"] = course_summary["avg_course_rating"].round(2)
course_summary["avg_professor_rating"] = course_summary["avg_professor_rating"].round(2)
course_summary["rating_gap"] = (
    course_summary["avg_professor_rating"] - course_summary["avg_course_rating"]
).round(2)


professor_course = (
    filtered.groupby(
        [
            "ProfessorDisplay",
            "Instructor_alias",
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
        ]
    )
    .agg(
        professor_rating=("avg_professor_rating", "mean"),
        course_rating=("avg_course_rating", "mean"),
        response_count=("CourseIdentifier", "count"),
    )
    .reset_index()
)

professor_course["professor_rating"] = professor_course["professor_rating"].round(2)
professor_course["course_rating"] = professor_course["course_rating"].round(2)
professor_course["rating_gap"] = (
    professor_course["professor_rating"] - professor_course["course_rating"]
).round(2)


# -------------------------------------------------
# Alert rules
# -------------------------------------------------
def assign_alert(row):
    if row["response_count"] < min_responses:
        return "Low Sample"

    if row["course_rating"] < review_threshold and row["professor_rating"] >= 4.0:
        return "Curriculum Review"

    if row["course_rating"] < review_threshold and row["professor_rating"] < review_threshold:
        return "Course + Professor Review"

    if row["professor_rating"] < review_threshold:
        return "Professor Review"

    if abs(row["rating_gap"]) >= gap_threshold:
        return "Large Rating Gap"

    return "OK"


professor_course["alert_type"] = professor_course.apply(assign_alert, axis=1)

alert_df = professor_course[professor_course["alert_type"] != "OK"].copy()


alert_priority = {
    "Course + Professor Review": 1,
    "Curriculum Review": 2,
    "Professor Review": 3,
    "Large Rating Gap": 4,
    "Low Sample": 5,
}

alert_df["alert_priority"] = alert_df["alert_type"].map(alert_priority).fillna(99)

alert_df = alert_df.sort_values(
    ["alert_priority", "course_rating", "professor_rating", "response_count"],
    ascending=[True, True, True, False],
)


# -------------------------------------------------
# Title
# -------------------------------------------------
st.markdown(
    """
    <div class="main-title">Alerts</div>
    <div class="subtitle">
    Decision-focused alerts for curriculum review, professor-course fit, low samples, and rating gaps.
    </div>
    """,
    unsafe_allow_html=True,
)


# -------------------------------------------------
# KPI row
# -------------------------------------------------
total_alerts = len(alert_df)
curriculum_alerts = alert_df[alert_df["alert_type"] == "Curriculum Review"].shape[0]
professor_alerts = alert_df[alert_df["alert_type"] == "Professor Review"].shape[0]
combined_alerts = alert_df[alert_df["alert_type"] == "Course + Professor Review"].shape[0]
gap_alerts = alert_df[alert_df["alert_type"] == "Large Rating Gap"].shape[0]

k1, k2, k3, k4, k5 = st.columns(5)

k1.metric("Total Alerts", total_alerts)
k2.metric("Curriculum Review", curriculum_alerts)
k3.metric("Professor Review", professor_alerts)
k4.metric("Course + Professor", combined_alerts)
k5.metric("Large Gaps", gap_alerts)

st.divider()


# -------------------------------------------------
# Alert distribution
# -------------------------------------------------
left, right = st.columns(2)

with left:
    st.markdown('<div class="section-title">Alert Type Distribution</div>', unsafe_allow_html=True)

    if alert_df.empty:
        st.success("No alerts found for selected filters.")
    else:
        alert_counts = (
            alert_df.groupby("alert_type")
            .size()
            .reset_index(name="count")
            .sort_values("count", ascending=False)
        )

        fig = px.bar(
            alert_counts,
            x="count",
            y="alert_type",
            orientation="h",
        )

        fig.update_layout(
            height=340,
            margin=dict(l=10, r=10, t=20, b=10),
            yaxis={"categoryorder": "total ascending"},
            showlegend=False,
        )

        st.plotly_chart(fig, use_container_width=True)

with right:
    st.markdown('<div class="section-title">Alert Scatter Map</div>', unsafe_allow_html=True)

    if alert_df.empty:
        st.info("No alert scatter map available.")
    else:
        fig = px.scatter(
            alert_df,
            x="course_rating",
            y="professor_rating",
            size="response_count",
            color="alert_type",
            hover_name="CourseIdentifier",
            hover_data=[
                "CourseTitle",
                "ProfessorDisplay",
                "Department",
                "College",
                "DeliveryCode",
                "rating_gap",
                "response_count",
            ],
        )

        fig.update_layout(
            height=340,
            margin=dict(l=10, r=10, t=20, b=10),
        )

        st.plotly_chart(fig, use_container_width=True)

st.divider()


# -------------------------------------------------
# Curriculum alerts
# -------------------------------------------------
st.markdown('<div class="section-title">Curriculum Review Candidates</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="section-note">Low course rating but stronger professor rating. This suggests the course structure or curriculum may need review.</div>',
    unsafe_allow_html=True,
)

curriculum_table = alert_df[alert_df["alert_type"] == "Curriculum Review"]

st.dataframe(
    curriculum_table[
        [
            "CourseIdentifier",
            "CourseTitle",
            "ProfessorDisplay",
            "Department",
            "College",
            "DeliveryCode",
            "course_rating",
            "professor_rating",
            "rating_gap",
            "response_count",
            "alert_type",
        ]
    ],
    use_container_width=True,
    height=280,
)

st.divider()


# -------------------------------------------------
# Professor/course combined alerts
# -------------------------------------------------
st.markdown('<div class="section-title">Course + Professor Review</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="section-note">Both course and professor ratings are low. This may indicate a fit, delivery, or broader quality issue.</div>',
    unsafe_allow_html=True,
)

combined_table = alert_df[alert_df["alert_type"] == "Course + Professor Review"]

st.dataframe(
    combined_table[
        [
            "ProfessorDisplay",
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
            "professor_rating",
            "course_rating",
            "rating_gap",
            "response_count",
            "alert_type",
        ]
    ],
    use_container_width=True,
    height=280,
)

st.divider()


# -------------------------------------------------
# All alerts table
# -------------------------------------------------
st.markdown('<div class="section-title">All Alerts</div>', unsafe_allow_html=True)

st.dataframe(
    alert_df[
        [
            "alert_type",
            "ProfessorDisplay",
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
            "professor_rating",
            "course_rating",
            "rating_gap",
            "response_count",
            "alert_priority",
        ]
    ],
    use_container_width=True,
    height=420,
)


# -------------------------------------------------
# Floating AI Assistant
# -------------------------------------------------
kpi_context = {
    "total_alerts": total_alerts,
    "curriculum_alerts": curriculum_alerts,
    "professor_alerts": professor_alerts,
    "combined_alerts": combined_alerts,
    "gap_alerts": gap_alerts,
    "min_responses": min_responses,
    "review_threshold": review_threshold,
    "gap_threshold": gap_threshold,
}

floating_dashboard_ai(
    page_name="Alerts",
    context_blocks={
        "KPIs": kpi_context,
        "All Alerts": alert_df,
        "Curriculum Review Candidates": curriculum_table,
        "Course + Professor Review": combined_table,
    },
)