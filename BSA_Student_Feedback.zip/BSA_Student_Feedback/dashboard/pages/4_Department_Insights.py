import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
import plotly.express as px
from dashboard.components.floating_ai import floating_dashboard_ai

# -------------------------------------------------
# Page setup
# -------------------------------------------------
st.set_page_config(
    page_title="Instructor Performance",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .block-container {
        padding-top: 3.5rem;
    }

    .main-title {
        font-size: 34px;
        font-weight: 800;
        color: #172033;
        margin-bottom: 0.2rem;
    }

    .subtitle {
        color: #667085;
        font-size: 15px;
        margin-bottom: 1.3rem;
    }

    .section-title {
        font-size: 22px;
        font-weight: 800;
        color: #111827;
        margin-top: 1.2rem;
        margin-bottom: 0.5rem;
    }

    .section-note {
        color: #667085;
        font-size: 14px;
        margin-bottom: 1rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# -------------------------------------------------
# Database
# -------------------------------------------------
engine = create_engine(
    "postgresql://postgres:admin@localhost:5432/course_eval_ai"
)


@st.cache_data
def load_data():
    df = pd.read_sql("SELECT * FROM bronze_cleaned_data", engine)

    try:
        instructor_map = pd.read_sql(
            """
            SELECT
                instructor_alias AS "Instructor_alias",
                "InstructorName" AS "ProfessorName"
            FROM bronze_instructor_alias_map
            """,
            engine,
        )

        df = df.merge(
            instructor_map,
            on="Instructor_alias",
            how="left",
        )

        df["ProfessorDisplay"] = df["ProfessorName"].fillna(df["Instructor_alias"])

    except Exception:
        df["ProfessorDisplay"] = df["Instructor_alias"]

    return df


df = load_data()


# -------------------------------------------------
# Ratings
# -------------------------------------------------
instructor_cols = ["i1", "i2", "i3", "i4", "i5", "i6", "i7"]
course_cols = ["c1", "c2", "c3", "c4", "c5"]

df["avg_professor_rating"] = df[instructor_cols].mean(axis=1, skipna=True)
df["avg_course_rating"] = df[course_cols].mean(axis=1, skipna=True)

df["rating_gap"] = (
    df["avg_professor_rating"] - df["avg_course_rating"]
).round(2)


# -------------------------------------------------
# Sidebar filters
# -------------------------------------------------
st.sidebar.title("Instructor Filters")

college_options = sorted(df["College"].dropna().unique())
department_options = sorted(df["Department"].dropna().unique())
delivery_options = sorted(df["DeliveryCode"].dropna().unique())
professor_options = sorted(df["ProfessorDisplay"].dropna().unique())
course_options = sorted(df["CourseIdentifier"].dropna().unique())

selected_colleges = st.sidebar.multiselect(
    "College",
    college_options,
    default=college_options,
)

selected_departments = st.sidebar.multiselect(
    "Department",
    department_options,
    default=department_options,
)

selected_delivery = st.sidebar.multiselect(
    "Delivery Mode",
    delivery_options,
    default=delivery_options,
)

selected_professor = st.sidebar.selectbox(
    "Professor",
    ["All"] + professor_options,
)

selected_course = st.sidebar.selectbox(
    "Course",
    ["All"] + course_options,
)

min_responses = st.sidebar.slider(
    "Minimum response count",
    min_value=1,
    max_value=30,
    value=3,
)


filtered = df[
    df["College"].isin(selected_colleges)
    & df["Department"].isin(selected_departments)
    & df["DeliveryCode"].isin(selected_delivery)
].copy()

if selected_professor != "All":
    filtered = filtered[filtered["ProfessorDisplay"] == selected_professor]

if selected_course != "All":
    filtered = filtered[filtered["CourseIdentifier"] == selected_course]

if filtered.empty:
    st.warning("No data found for selected filters.")
    st.stop()


# -------------------------------------------------
# Aggregations
# -------------------------------------------------
professor_summary = (
    filtered.groupby(
        [
            "ProfessorDisplay",
            "Instructor_alias",
            "Department",
            "College",
            "InstructorType",
        ]
    )
    .agg(
        avg_professor_rating=("avg_professor_rating", "mean"),
        avg_course_rating=("avg_course_rating", "mean"),
        response_count=("ProfessorDisplay", "count"),
        course_count=("CourseIdentifier", "nunique"),
    )
    .reset_index()
)

professor_summary["avg_professor_rating"] = professor_summary["avg_professor_rating"].round(2)
professor_summary["avg_course_rating"] = professor_summary["avg_course_rating"].round(2)
professor_summary["rating_gap"] = (
    professor_summary["avg_professor_rating"] - professor_summary["avg_course_rating"]
).round(2)


professor_course = (
    filtered.groupby(
        [
            "ProfessorDisplay",
            "Instructor_alias",
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
            "InstructorType",
        ]
    )
    .agg(
        professor_rating=("avg_professor_rating", "mean"),
        course_rating=("avg_course_rating", "mean"),
        response_count=("CourseIdentifier", "count"),
    )
    .reset_index()
)

professor_course["professor_rating"] = professor_course["professor_rating"].round(2)
professor_course["course_rating"] = professor_course["course_rating"].round(2)
professor_course["rating_gap"] = (
    professor_course["professor_rating"] - professor_course["course_rating"]
).round(2)


professor_course["risk_status"] = professor_course.apply(
    lambda row: "Low sample"
    if row["response_count"] < min_responses
    else "Review"
    if row["course_rating"] < 3.5 or row["professor_rating"] < 3.5
    else "Monitor"
    if row["course_rating"] < 4.0 or row["professor_rating"] < 4.0
    else "Strong",
    axis=1,
)


# -------------------------------------------------
# Title
# -------------------------------------------------
st.markdown(
    """
    <div class="main-title">Instructor Performance</div>
    <div class="subtitle">
    Professor-level performance, course fit, delivery mode behavior, and review signals.
    </div>
    """,
    unsafe_allow_html=True,
)


# -------------------------------------------------
# KPI row
# -------------------------------------------------
avg_professor_rating = round(filtered["avg_professor_rating"].mean(), 2)
avg_course_rating = round(filtered["avg_course_rating"].mean(), 2)
total_evaluations = len(filtered)
total_professors = filtered["ProfessorDisplay"].nunique()
total_courses = filtered["CourseIdentifier"].nunique()

review_professors = professor_summary[
    (professor_summary["avg_professor_rating"] < 3.5)
    & (professor_summary["response_count"] >= min_responses)
].shape[0]

k1, k2, k3, k4, k5 = st.columns(5)

k1.metric("Avg Professor Rating", avg_professor_rating)
k2.metric("Avg Course Rating", avg_course_rating)
k3.metric("Evaluations", total_evaluations)
k4.metric("Professors", total_professors)
k5.metric("Review Professors", review_professors)

st.divider()


# -------------------------------------------------
# Professor visualizations
# -------------------------------------------------
left, right = st.columns(2)

with left:
    st.markdown('<div class="section-title">Lowest-Rated Professors</div>', unsafe_allow_html=True)

    low_professors = (
        professor_summary[professor_summary["response_count"] >= min_responses]
        .sort_values(["avg_professor_rating", "response_count"], ascending=[True, False])
        .head(10)
    )

    fig = px.bar(
        low_professors,
        x="avg_professor_rating",
        y="ProfessorDisplay",
        orientation="h",
        hover_data=[
            "Department",
            "College",
            "InstructorType",
            "response_count",
            "course_count",
        ],
    )

    fig.update_layout(
        height=360,
        margin=dict(l=10, r=10, t=20, b=10),
        yaxis={"categoryorder": "total ascending"},
        showlegend=False,
    )

    st.plotly_chart(fig, use_container_width=True)

with right:
    st.markdown('<div class="section-title">Professor vs Course Rating Gap</div>', unsafe_allow_html=True)

    gap_professors = (
        professor_summary[professor_summary["response_count"] >= min_responses]
        .sort_values("rating_gap", ascending=False)
        .head(10)
    )

    fig = px.bar(
        gap_professors,
        x="rating_gap",
        y="ProfessorDisplay",
        orientation="h",
        hover_data=[
            "Department",
            "College",
            "InstructorType",
            "avg_professor_rating",
            "avg_course_rating",
            "response_count",
            "course_count",
        ],
    )

    fig.update_layout(
        height=360,
        margin=dict(l=10, r=10, t=20, b=10),
        yaxis={"categoryorder": "total ascending"},
        showlegend=False,
    )

    st.plotly_chart(fig, use_container_width=True)

st.divider()


# -------------------------------------------------
# Individual instructor view
# -------------------------------------------------
st.markdown('<div class="section-title">Individual Professor Course Performance</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="section-note">Select a professor to see courses taught, course fit, and rating gaps.</div>',
    unsafe_allow_html=True,
)

if selected_professor == "All":
    professor_pick = st.selectbox(
        "Choose a professor to inspect",
        sorted(professor_course["ProfessorDisplay"].dropna().unique()),
    )
else:
    professor_pick = selected_professor

single_professor = (
    professor_course[professor_course["ProfessorDisplay"] == professor_pick]
    .sort_values(["professor_rating", "course_rating"], ascending=[False, False])
)

st.markdown(f"### {professor_pick}")

p1, p2, p3, p4 = st.columns(4)

p1.metric("Courses Taught", single_professor["CourseIdentifier"].nunique())
p2.metric("Total Responses", int(single_professor["response_count"].sum()))
p3.metric("Avg Professor Rating", round(single_professor["professor_rating"].mean(), 2))
p4.metric("Avg Course Rating", round(single_professor["course_rating"].mean(), 2))

fig = px.bar(
    single_professor,
    x="CourseIdentifier",
    y=["professor_rating", "course_rating"],
    barmode="group",
    hover_data=[
        "CourseTitle",
        "Department",
        "College",
        "DeliveryCode",
        "response_count",
        "rating_gap",
        "risk_status",
    ],
    title=f"Courses Taught by {professor_pick}",
)

fig.update_layout(
    height=380,
    margin=dict(l=10, r=10, t=45, b=10),
)

st.plotly_chart(fig, use_container_width=True)

st.dataframe(
    single_professor[
        [
            "ProfessorDisplay",
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
            "InstructorType",
            "professor_rating",
            "course_rating",
            "rating_gap",
            "response_count",
            "risk_status",
        ]
    ],
    use_container_width=True,
    height=320,
)

st.divider()


# -------------------------------------------------
# Scatter: professor-course fit
# -------------------------------------------------
st.markdown('<div class="section-title">Professor-Course Fit Map</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="section-note">High professor rating with low course rating may suggest curriculum/design issues. Low professor and low course rating may suggest a course-fit or delivery issue.</div>',
    unsafe_allow_html=True,
)

scatter_df = professor_course[
    professor_course["response_count"] >= min_responses
].copy()

fig = px.scatter(
    scatter_df,
    x="course_rating",
    y="professor_rating",
    size="response_count",
    color="risk_status",
    hover_name="ProfessorDisplay",
    hover_data=[
        "CourseIdentifier",
        "CourseTitle",
        "Department",
        "College",
        "DeliveryCode",
        "rating_gap",
        "response_count",
    ],
    title="Professor Rating vs Course Rating",
)

fig.update_layout(
    height=560,
    margin=dict(l=10, r=10, t=45, b=10),
)

st.plotly_chart(fig, use_container_width=True)

st.divider()


# -------------------------------------------------
# Heatmap
# -------------------------------------------------
st.markdown('<div class="section-title">Professor-Course Heatmap</div>', unsafe_allow_html=True)

matrix_metric = st.radio(
    "Heatmap metric",
    ["professor_rating", "course_rating", "rating_gap", "response_count"],
    horizontal=True,
)

heatmap_df = professor_course[
    professor_course["response_count"] >= min_responses
].copy()

pivot = heatmap_df.pivot_table(
    index="ProfessorDisplay",
    columns="CourseIdentifier",
    values=matrix_metric,
    aggfunc="mean",
)

fig = px.imshow(
    pivot,
    aspect="auto",
    title=f"{matrix_metric} by Professor and Course",
)

fig.update_layout(
    height=620,
    margin=dict(l=10, r=10, t=45, b=10),
)

st.plotly_chart(fig, use_container_width=True)


# -------------------------------------------------
# Professor performance table
# -------------------------------------------------
st.markdown('<div class="section-title">Professor Performance Table</div>', unsafe_allow_html=True)

st.dataframe(
    professor_summary.sort_values(["avg_professor_rating", "response_count"], ascending=[True, False])[
        [
            "ProfessorDisplay",
            "Department",
            "College",
            "InstructorType",
            "avg_professor_rating",
            "avg_course_rating",
            "rating_gap",
            "response_count",
            "course_count",
        ]
    ],
    use_container_width=True,
    height=360,
)



# -------------------------------------------------
# Floating AI Assistant
# -------------------------------------------------
kpi_context = {
    "avg_course_rating": avg_course_rating,
    "avg_professor_rating": avg_professor_rating,
    "total_evaluations": total_evaluations,
    "total_departments": total_departments,
    "total_courses": total_courses,
    "review_departments": review_departments,
    "selected_colleges": selected_colleges,
    "selected_departments": selected_departments,
    "selected_delivery": selected_delivery,
    "min_responses": min_responses,
}

floating_dashboard_ai(
    page_name="Department Insights",
    context_blocks={
        "KPIs": kpi_context,
        "Department Summary": department_summary,
        "Course Summary": course_summary,
        "Professor Summary": professor_summary,
        "Delivery Summary": delivery_summary,
        "Selected Department Courses": dept_courses,
        "Selected Department Professors": dept_professors,
    },
)