import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
import plotly.express as px
from dashboard.components.floating_ai import floating_dashboard_ai


# -------------------------------------------------
# Page setup
# -------------------------------------------------
st.set_page_config(
    page_title="Course Performance",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .block-container {
        padding-top: 3.5rem;
    }

    .main-title {
        font-size: 34px;
        font-weight: 800;
        color: #172033;
        margin-bottom: 0.2rem;
    }

    .subtitle {
        color: #667085;
        font-size: 15px;
        margin-bottom: 1.3rem;
    }

    .section-title {
        font-size: 22px;
        font-weight: 800;
        color: #111827;
        margin-top: 1.2rem;
        margin-bottom: 0.5rem;
    }

    .section-note {
        color: #667085;
        font-size: 14px;
        margin-bottom: 1rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# -------------------------------------------------
# Database
# -------------------------------------------------
engine = create_engine(
    "postgresql://postgres:admin@localhost:5432/course_eval_ai"
)


@st.cache_data
def load_data():
    df = pd.read_sql("SELECT * FROM bronze_cleaned_data", engine)

    try:
        instructor_map = pd.read_sql(
            """
            SELECT
                instructor_alias AS "Instructor_alias",
                "InstructorName" AS "ProfessorName"
            FROM bronze_instructor_alias_map
            """,
            engine,
        )

        df = df.merge(
            instructor_map,
            on="Instructor_alias",
            how="left",
        )

        df["ProfessorDisplay"] = df["ProfessorName"].fillna(df["Instructor_alias"])

    except Exception:
        df["ProfessorDisplay"] = df["Instructor_alias"]

    return df


df = load_data()


# -------------------------------------------------
# Ratings
# -------------------------------------------------
instructor_cols = ["i1", "i2", "i3", "i4", "i5", "i6", "i7"]
course_cols = ["c1", "c2", "c3", "c4", "c5"]

df["avg_professor_rating"] = df[instructor_cols].mean(axis=1, skipna=True)
df["avg_course_rating"] = df[course_cols].mean(axis=1, skipna=True)

df["rating_gap"] = (
    df["avg_professor_rating"] - df["avg_course_rating"]
).round(2)


# -------------------------------------------------
# Sidebar filters
# -------------------------------------------------
st.sidebar.title("Course Filters")

college_options = sorted(df["College"].dropna().unique())
department_options = sorted(df["Department"].dropna().unique())
delivery_options = sorted(df["DeliveryCode"].dropna().unique())
course_options = sorted(df["CourseIdentifier"].dropna().unique())
professor_options = sorted(df["ProfessorDisplay"].dropna().unique())

selected_colleges = st.sidebar.multiselect(
    "College",
    college_options,
    default=college_options,
)

selected_departments = st.sidebar.multiselect(
    "Department",
    department_options,
    default=department_options,
)

selected_delivery = st.sidebar.multiselect(
    "Delivery Mode",
    delivery_options,
    default=delivery_options,
)

selected_course = st.sidebar.selectbox(
    "Course",
    ["All"] + course_options,
)

selected_professor = st.sidebar.selectbox(
    "Professor",
    ["All"] + professor_options,
)

min_responses = st.sidebar.slider(
    "Minimum response count",
    min_value=1,
    max_value=30,
    value=3,
)


filtered = df[
    df["College"].isin(selected_colleges)
    & df["Department"].isin(selected_departments)
    & df["DeliveryCode"].isin(selected_delivery)
].copy()

if selected_course != "All":
    filtered = filtered[filtered["CourseIdentifier"] == selected_course]

if selected_professor != "All":
    filtered = filtered[filtered["ProfessorDisplay"] == selected_professor]

if filtered.empty:
    st.warning("No data found for selected filters.")
    st.stop()


# -------------------------------------------------
# Aggregations
# -------------------------------------------------
course_summary = (
    filtered.groupby(
        [
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
        ]
    )
    .agg(
        avg_course_rating=("avg_course_rating", "mean"),
        avg_professor_rating=("avg_professor_rating", "mean"),
        response_count=("CourseIdentifier", "count"),
        professor_count=("ProfessorDisplay", "nunique"),
    )
    .reset_index()
)

course_summary["avg_course_rating"] = course_summary["avg_course_rating"].round(2)
course_summary["avg_professor_rating"] = course_summary["avg_professor_rating"].round(2)
course_summary["rating_gap"] = (
    course_summary["avg_professor_rating"] - course_summary["avg_course_rating"]
).round(2)


professor_course = (
    filtered.groupby(
        [
            "ProfessorDisplay",
            "Instructor_alias",
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
        ]
    )
    .agg(
        professor_rating=("avg_professor_rating", "mean"),
        course_rating=("avg_course_rating", "mean"),
        response_count=("CourseIdentifier", "count"),
    )
    .reset_index()
)

professor_course["professor_rating"] = professor_course["professor_rating"].round(2)
professor_course["course_rating"] = professor_course["course_rating"].round(2)
professor_course["rating_gap"] = (
    professor_course["professor_rating"] - professor_course["course_rating"]
).round(2)


professor_course["risk_status"] = professor_course.apply(
    lambda row: "Low sample"
    if row["response_count"] < min_responses
    else "Review"
    if row["course_rating"] < 3.5 or row["professor_rating"] < 3.5
    else "Monitor"
    if row["course_rating"] < 4.0 or row["professor_rating"] < 4.0
    else "Strong",
    axis=1,
)


# -------------------------------------------------
# Title
# -------------------------------------------------
st.markdown(
    """
    <div class="main-title">Course Performance</div>
    <div class="subtitle">
    Course-level performance, professor-course fit, and heatmap view.
    </div>
    """,
    unsafe_allow_html=True,
)


# -------------------------------------------------
# KPI row
# -------------------------------------------------
avg_course_rating = round(filtered["avg_course_rating"].mean(), 2)
avg_professor_rating = round(filtered["avg_professor_rating"].mean(), 2)
total_evaluations = len(filtered)
total_courses = filtered["CourseIdentifier"].nunique()
total_professors = filtered["ProfessorDisplay"].nunique()

review_courses = course_summary[
    (course_summary["avg_course_rating"] < 3.5)
    & (course_summary["response_count"] >= min_responses)
].shape[0]

k1, k2, k3, k4, k5 = st.columns(5)

k1.metric("Avg Course Rating", avg_course_rating)
k2.metric("Avg Professor Rating", avg_professor_rating)
k3.metric("Evaluations", total_evaluations)
k4.metric("Courses", total_courses)
k5.metric("Review Courses", review_courses)

st.divider()


# -------------------------------------------------
# Course visualizations
# -------------------------------------------------
left, right = st.columns(2)

with left:
    st.markdown('<div class="section-title">Lowest-Rated Courses</div>', unsafe_allow_html=True)

    low_courses = (
        course_summary[course_summary["response_count"] >= min_responses]
        .sort_values(["avg_course_rating", "response_count"], ascending=[True, False])
        .head(10)
    )

    fig = px.bar(
        low_courses,
        x="avg_course_rating",
        y="CourseIdentifier",
        orientation="h",
        hover_data=[
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
            "response_count",
            "professor_count",
        ],
    )

    fig.update_layout(
        height=360,
        margin=dict(l=10, r=10, t=20, b=10),
        yaxis={"categoryorder": "total ascending"},
        showlegend=False,
    )

    st.plotly_chart(fig, use_container_width=True)

with right:
    st.markdown('<div class="section-title">Course vs Professor Rating Gap</div>', unsafe_allow_html=True)

    gap_courses = (
        course_summary[course_summary["response_count"] >= min_responses]
        .sort_values("rating_gap", ascending=False)
        .head(10)
    )

    fig = px.bar(
        gap_courses,
        x="rating_gap",
        y="CourseIdentifier",
        orientation="h",
        hover_data=[
            "CourseTitle",
            "Department",
            "College",
            "avg_course_rating",
            "avg_professor_rating",
            "response_count",
        ],
    )

    fig.update_layout(
        height=360,
        margin=dict(l=10, r=10, t=20, b=10),
        yaxis={"categoryorder": "total ascending"},
        showlegend=False,
    )

    st.plotly_chart(fig, use_container_width=True)

st.divider()


# -------------------------------------------------
# Individual professor view for selected course
# -------------------------------------------------
st.markdown('<div class="section-title">Individual Professors by Course</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="section-note">Shows which professors taught each course and how professor rating compares with course rating.</div>',
    unsafe_allow_html=True,
)

if selected_course == "All":
    course_pick = st.selectbox(
        "Choose a course to inspect",
        sorted(professor_course["CourseIdentifier"].dropna().unique()),
    )
else:
    course_pick = selected_course

course_professors = (
    professor_course[professor_course["CourseIdentifier"] == course_pick]
    .sort_values(["professor_rating", "course_rating"], ascending=[False, False])
)

selected_course_title = (
    course_professors["CourseTitle"].iloc[0]
    if not course_professors.empty
    else ""
)

st.markdown(f"### {course_pick} — {selected_course_title}")

p1, p2, p3, p4 = st.columns(4)

p1.metric("Professors", course_professors["ProfessorDisplay"].nunique())
p2.metric("Total Responses", int(course_professors["response_count"].sum()))
p3.metric("Avg Course Rating", round(course_professors["course_rating"].mean(), 2))
p4.metric("Avg Professor Rating", round(course_professors["professor_rating"].mean(), 2))

fig = px.bar(
    course_professors,
    x="ProfessorDisplay",
    y=["professor_rating", "course_rating"],
    barmode="group",
    hover_data=[
        "CourseTitle",
        "Department",
        "College",
        "DeliveryCode",
        "response_count",
        "rating_gap",
        "risk_status",
    ],
    title=f"Professor Performance for {course_pick}",
)

fig.update_layout(
    height=380,
    margin=dict(l=10, r=10, t=45, b=10),
)

st.plotly_chart(fig, use_container_width=True)

st.dataframe(
    course_professors[
        [
            "ProfessorDisplay",
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
            "professor_rating",
            "course_rating",
            "rating_gap",
            "response_count",
            "risk_status",
        ]
    ],
    use_container_width=True,
    height=320,
)

st.divider()


# -------------------------------------------------
# Heatmap visualization
# -------------------------------------------------
st.markdown('<div class="section-title">Professor-Course Heatmap</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="section-note">Heatmap shows how professors perform across courses.</div>',
    unsafe_allow_html=True,
)

matrix_metric = st.radio(
    "Heatmap metric",
    ["professor_rating", "course_rating", "rating_gap", "response_count"],
    horizontal=True,
)

heatmap_df = professor_course[
    professor_course["response_count"] >= min_responses
].copy()

pivot = heatmap_df.pivot_table(
    index="ProfessorDisplay",
    columns="CourseIdentifier",
    values=matrix_metric,
    aggfunc="mean",
)

fig = px.imshow(
    pivot,
    aspect="auto",
    title=f"{matrix_metric} by Professor and Course",
)

fig.update_layout(
    height=620,
    margin=dict(l=10, r=10, t=45, b=10),
)

st.plotly_chart(fig, use_container_width=True)


# -------------------------------------------------
# Course performance table
# -------------------------------------------------
st.markdown('<div class="section-title">Course Performance Table</div>', unsafe_allow_html=True)

st.dataframe(
    course_summary.sort_values(["avg_course_rating", "response_count"], ascending=[True, False])[
        [
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
            "avg_course_rating",
            "avg_professor_rating",
            "rating_gap",
            "response_count",
            "professor_count",
        ]
    ],
    use_container_width=True,
    height=360,
)


# -------------------------------------------------
# Floating AI Assistant
# -------------------------------------------------
kpi_context = {
    "avg_course_rating": avg_course_rating,
    "avg_professor_rating": avg_professor_rating,
    "total_evaluations": total_evaluations,
    "total_courses": total_courses,
    "total_professors": total_professors,
    "review_courses": review_courses,
    "selected_course": selected_course,
    "selected_professor": selected_professor,
    "min_responses": min_responses,
}

floating_dashboard_ai(
    page_name="Course Performance",
    context_blocks={
        "KPIs": kpi_context,
        "Course Summary": course_summary,
        "Professor Course Detail": professor_course,
        "Selected Course Professors": course_professors,
    },
)