import json
import pandas as pd
import streamlit as st
from google import genai


# -------------------------------------------------
# Gemini config
# -------------------------------------------------
GEMINI_API_KEY = "Replace with your api"
GEMINI_MODEL = "gemini-3-flash-preview"


# -------------------------------------------------
# Helpers
# -------------------------------------------------
def _safe_round(value):
    try:
        return round(float(value), 2)
    except Exception:
        return value


def dataframe_context(name: str, df: pd.DataFrame, max_rows: int = 20) -> str:
    if df is None or df.empty:
        return f"\n## {name}\nNo data available.\n"

    context = {
        "section": name,
        "row_count": int(len(df)),
        "columns": list(df.columns),
        "sample_rows": df.head(max_rows).where(pd.notnull(df), None).to_dict(orient="records"),
    }

    numeric_cols = df.select_dtypes(include="number").columns.tolist()

    if numeric_cols:
        summary = {}

        for col in numeric_cols:
            summary[col] = {
                "min": _safe_round(df[col].min()),
                "max": _safe_round(df[col].max()),
                "mean": _safe_round(df[col].mean()),
                "median": _safe_round(df[col].median()),
            }

        context["numeric_summary"] = summary

    return "\n## " + name + "\n" + json.dumps(context, indent=2, default=str)


def dict_context(name: str, data: dict) -> str:
    return "\n## " + name + "\n" + json.dumps(data, indent=2, default=str)


def text_context(name: str, text: str) -> str:
    return f"\n## {name}\n{text}\n"


def build_context(page_name: str, context_blocks: dict, selected_block: str) -> str:
    parts = [
        f"# Current dashboard page: {page_name}",
        "This is dashboard context generated from the current filtered page.",
        "Use only this context. Do not invent missing data.",
    ]

    if selected_block == "Full Page Context":
        items = context_blocks.items()
    else:
        items = [(selected_block, context_blocks[selected_block])]

    for name, value in items:
        if isinstance(value, pd.DataFrame):
            parts.append(dataframe_context(name, value))
        elif isinstance(value, dict):
            parts.append(dict_context(name, value))
        else:
            parts.append(text_context(name, str(value)))

    context_text = "\n".join(parts)

    # Keep prompt small enough for stable responses
    max_chars = 18000

    if len(context_text) > max_chars:
        context_text = context_text[:max_chars] + "\n\n[Context truncated due to length.]"

    return context_text


def ask_dashboard_ai(question: str, page_name: str, dashboard_context: str) -> str:
    if not GEMINI_API_KEY:
        return "Gemini API key is missing."

    client = genai.Client(api_key=GEMINI_API_KEY)

    prompt = f"""
You are an AI analyst for a university course evaluation intelligence dashboard.

The user is looking at this dashboard page:
{page_name}

You must answer using ONLY the dashboard context below.

Rules:
- Do not hallucinate.
- Do not invent courses, professors, departments, ratings, or trends not present in the context.
- If the context does not contain enough data, say what is missing.
- Always mention the evidence you used: course rating, professor rating, response count, rating gap, risk status, department, or delivery mode when available.
- If the user asks for a recommendation, classify the issue clearly:
  1. Low course rating + high professor rating = possible curriculum/course design issue.
  2. Low professor rating + good course rating = possible instructor/delivery issue.
  3. Both low = possible professor-course fit or broader quality issue.
  4. Low response count = weak confidence.
- Keep the answer direct and useful.

Dashboard context:
{dashboard_context}

User question:
{question}
"""

    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
    )

    return response.text


# -------------------------------------------------
# Floating AI widget
# -------------------------------------------------
def floating_dashboard_ai(page_name: str, context_blocks: dict):
    """
    Add this function at the bottom of any Streamlit dashboard page.

    Example:
        floating_dashboard_ai(
            page_name="Executive Summary",
            context_blocks={
                "KPIs": kpi_context,
                "Course Summary": course_summary,
                "Professor Summary": professor_summary,
            }
        )
    """

    st.markdown(
        """
        <style>
        .floating-ai-box {
            position: fixed;
            right: 24px;
            bottom: 24px;
            width: 370px;
            max-height: 70vh;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 18px;
            box-shadow: 0px 8px 30px rgba(0, 0, 0, 0.18);
            z-index: 9999;
            padding: 14px;
        }

        .floating-ai-title {
            font-size: 16px;
            font-weight: 800;
            color: #111827;
            margin-bottom: 4px;
        }

        .floating-ai-note {
            font-size: 12px;
            color: #667085;
            margin-bottom: 8px;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    with st.expander("🤖 Ask AI about this dashboard", expanded=False):
        st.caption(
            "Ask about the current dashboard data. The AI receives only the selected dashboard context."
        )

        context_names = ["Full Page Context"] + list(context_blocks.keys())

        selected_context = st.selectbox(
            "What should AI analyze?",
            context_names,
            key=f"{page_name}_ai_context_select",
        )

        question = st.text_area(
            "Ask a question",
            placeholder=(
                "Example: What courses need curriculum review? "
                "Which professor-course match looks weak? "
                "What should leadership inspect first?"
            ),
            height=100,
            key=f"{page_name}_ai_question",
        )

        ask_clicked = st.button(
            "Ask AI",
            key=f"{page_name}_ai_button",
            type="primary",
        )

        if ask_clicked:
            if not question.strip():
                st.warning("Type a question first.")
                return

            dashboard_context = build_context(
                page_name=page_name,
                context_blocks=context_blocks,
                selected_block=selected_context,
            )

            with st.spinner("AI is analyzing the dashboard context..."):
                answer = ask_dashboard_ai(
                    question=question,
                    page_name=page_name,
                    dashboard_context=dashboard_context,
                )

            st.markdown("### AI Response")
            st.write(answer)

            show_debug = st.checkbox(
                "Show debug context sent to AI",
                value=False,
                key=f"{page_name}_ai_debug_checkbox",
            )

            if show_debug:
                st.code(dashboard_context[:6000])