import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
import plotly.express as px
from course_eval_ai.agents.text_to_sql_agent import ask_database
from dashboard.components.floating_ai import floating_dashboard_ai



# -------------------------------------------------
# Page setup
# -------------------------------------------------
st.set_page_config(
    page_title="Course Evaluation Intelligence Dashboard",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown(
    """
    <style>
    .block-container {
        padding-top: 3.5rem;
    }

    .main-title {
        font-size: 36px;
        font-weight: 800;
        color: #172033;
        margin-bottom: 0.2rem;
    }

    .subtitle {
        color: #667085;
        font-size: 15px;
        margin-bottom: 1.5rem;
    }

    .metric-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 16px;
        padding: 18px;
        box-shadow: 0px 3px 12px rgba(0,0,0,0.05);
    }

    .metric-label {
        font-size: 13px;
        color: #667085;
        font-weight: 600;
    }

    .metric-value {
        font-size: 30px;
        color: #111827;
        font-weight: 800;
    }

    .section-title {
        font-size: 24px;
        font-weight: 800;
        color: #111827;
        margin-top: 1.5rem;
        margin-bottom: 0.5rem;
    }

    .section-note {
        color: #667085;
        font-size: 14px;
        margin-bottom: 1rem;
    }
    </style>
    """,
    unsafe_allow_html=True
)


# -------------------------------------------------
# Database
# -------------------------------------------------
engine = create_engine(
    "Replace with your database url"
)


@st.cache_data
def load_data():
    df = pd.read_sql("SELECT * FROM bronze_cleaned_data", engine)

    try:
        instructor_map = pd.read_sql(
            """
            SELECT
                instructor_alias AS "Instructor_alias",
                "InstructorName" AS "ProfessorName"
            FROM bronze_instructor_alias_map
            """,
            engine
        )

        df = df.merge(
            instructor_map,
            on="Instructor_alias",
            how="left"
        )

        df["ProfessorDisplay"] = df["ProfessorName"].fillna(df["Instructor_alias"])

    except Exception:
        df["ProfessorDisplay"] = df["Instructor_alias"]

    return df


df = load_data()


# -------------------------------------------------
# Ratings setup
# -------------------------------------------------
instructor_cols = ["i1", "i2", "i3", "i4", "i5", "i6", "i7"]
course_cols = ["c1", "c2", "c3", "c4", "c5"]

df["avg_instructor_rating"] = df[instructor_cols].mean(axis=1, skipna=True)
df["avg_course_rating"] = df[course_cols].mean(axis=1, skipna=True)

df["rating_gap"] = (
    df["avg_instructor_rating"] - df["avg_course_rating"]
).round(2)


# -------------------------------------------------
# Sidebar filters
# -------------------------------------------------
st.sidebar.title("Filters")

college_options = sorted(df["College"].dropna().unique())
department_options = sorted(df["Department"].dropna().unique())
delivery_options = sorted(df["DeliveryCode"].dropna().unique())
professor_options = sorted(df["ProfessorDisplay"].dropna().unique())
course_options = sorted(df["CourseIdentifier"].dropna().unique())

selected_colleges = st.sidebar.multiselect(
    "College",
    college_options,
    default=college_options
)

selected_departments = st.sidebar.multiselect(
    "Department",
    department_options,
    default=department_options
)

selected_delivery = st.sidebar.multiselect(
    "Delivery Mode",
    delivery_options,
    default=delivery_options
)

selected_professor = st.sidebar.selectbox(
    "Professor",
    ["All"] + professor_options
)

selected_course = st.sidebar.selectbox(
    "Course",
    ["All"] + course_options
)

min_responses = st.sidebar.slider(
    "Minimum response count",
    min_value=1,
    max_value=30,
    value=3
)


filtered = df[
    df["College"].isin(selected_colleges)
    & df["Department"].isin(selected_departments)
    & df["DeliveryCode"].isin(selected_delivery)
].copy()

if selected_professor != "All":
    filtered = filtered[filtered["ProfessorDisplay"] == selected_professor]

if selected_course != "All":
    filtered = filtered[filtered["CourseIdentifier"] == selected_course]

if filtered.empty:
    st.warning("No data found for selected filters.")
    st.stop()


# -------------------------------------------------
# Title
# -------------------------------------------------
st.markdown(
    """
    <div class="main-title">Course Evaluation Intelligence Dashboard</div>
    <div class="subtitle">
    Professor-course rating analysis using internal professor names.
    </div>
    """,
    unsafe_allow_html=True
)


# -------------------------------------------------
# KPIs
# -------------------------------------------------
avg_course_rating = round(filtered["avg_course_rating"].mean(), 2)
avg_instructor_rating = round(filtered["avg_instructor_rating"].mean(), 2)
total_evaluations = len(filtered)
total_courses = filtered["CourseIdentifier"].nunique()
total_professors = filtered["Instructor_alias"].nunique()

k1, k2, k3, k4, k5 = st.columns(5)

with k1:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-label">Avg Course Rating</div>
            <div class="metric-value">{avg_course_rating}</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with k2:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-label">Avg Professor Rating</div>
            <div class="metric-value">{avg_instructor_rating}</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with k3:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-label">Evaluations</div>
            <div class="metric-value">{total_evaluations}</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with k4:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-label">Courses</div>
            <div class="metric-value">{total_courses}</div>
        </div>
        """,
        unsafe_allow_html=True
    )

with k5:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-label">Professors</div>
            <div class="metric-value">{total_professors}</div>
        </div>
        """,
        unsafe_allow_html=True
    )


# -------------------------------------------------
# Aggregations
# -------------------------------------------------
professor_course = (
    filtered.groupby(
        [
            "ProfessorDisplay",
            "Instructor_alias",
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
        ]
    )
    .agg(
        professor_rating=("avg_instructor_rating", "mean"),
        course_rating=("avg_course_rating", "mean"),
        response_count=("CourseIdentifier", "count"),
    )
    .reset_index()
)

professor_course["professor_rating"] = professor_course["professor_rating"].round(2)
professor_course["course_rating"] = professor_course["course_rating"].round(2)
professor_course["rating_gap"] = (
    professor_course["professor_rating"] - professor_course["course_rating"]
).round(2)

professor_course["risk_status"] = professor_course.apply(
    lambda row: "Low sample"
    if row["response_count"] < min_responses
    else "Review"
    if row["course_rating"] < 3.5 or row["professor_rating"] < 3.5
    else "Monitor"
    if row["course_rating"] < 4.0 or row["professor_rating"] < 4.0
    else "Strong",
    axis=1
)


course_summary = (
    filtered.groupby(
        [
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
        ]
    )
    .agg(
        avg_course_rating=("avg_course_rating", "mean"),
        avg_professor_rating=("avg_instructor_rating", "mean"),
        response_count=("CourseIdentifier", "count"),
        professor_count=("ProfessorDisplay", "nunique"),
    )
    .reset_index()
)

course_summary["avg_course_rating"] = course_summary["avg_course_rating"].round(2)
course_summary["avg_professor_rating"] = course_summary["avg_professor_rating"].round(2)
course_summary["rating_gap"] = (
    course_summary["avg_professor_rating"] - course_summary["avg_course_rating"]
).round(2)


professor_summary = (
    filtered.groupby(["ProfessorDisplay", "Instructor_alias", "Department", "College"])
    .agg(
        avg_professor_rating=("avg_instructor_rating", "mean"),
        avg_course_rating=("avg_course_rating", "mean"),
        response_count=("ProfessorDisplay", "count"),
        course_count=("CourseIdentifier", "nunique"),
    )
    .reset_index()
)

professor_summary["avg_professor_rating"] = professor_summary["avg_professor_rating"].round(2)
professor_summary["avg_course_rating"] = professor_summary["avg_course_rating"].round(2)
professor_summary["rating_gap"] = (
    professor_summary["avg_professor_rating"] - professor_summary["avg_course_rating"]
).round(2)


department_summary = (
    filtered.groupby(["Department", "College"])
    .agg(
        avg_course_rating=("avg_course_rating", "mean"),
        avg_professor_rating=("avg_instructor_rating", "mean"),
        response_count=("Department", "count"),
        course_count=("CourseIdentifier", "nunique"),
        professor_count=("ProfessorDisplay", "nunique"),
    )
    .reset_index()
)

department_summary["avg_course_rating"] = department_summary["avg_course_rating"].round(2)
department_summary["avg_professor_rating"] = department_summary["avg_professor_rating"].round(2)


# -------------------------------------------------
# Tabs
# -------------------------------------------------
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
    [
        "Overview",
        "Professor → Courses",
        "Course → Professors",
        "Professor/Course Matrix",
        "Risk + Gaps",
        "Ask Database",
    ]
)


# -------------------------------------------------
# Overview
# -------------------------------------------------
with tab1:
    st.markdown('<div class="section-title">Executive Overview</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="section-note">Quick summary of course health, professor performance, and review risks.</div>',
        unsafe_allow_html=True,
    )

    # -----------------------------
    # Small executive KPI row
    # -----------------------------
    review_count = professor_course[
        professor_course["risk_status"].isin(["Review", "Low sample"])
    ].shape[0]

    low_course_count = course_summary[
        (course_summary["avg_course_rating"] < 3.5)
        & (course_summary["response_count"] >= min_responses)
    ].shape[0]

    low_professor_count = professor_summary[
        (professor_summary["avg_professor_rating"] < 3.5)
        & (professor_summary["response_count"] >= min_responses)
    ].shape[0]

    big_gap_count = professor_course[
        professor_course["rating_gap"].abs() >= 0.75
    ].shape[0]

    o1, o2, o3, o4 = st.columns(4)

    o1.metric("Review Items", review_count)
    o2.metric("Low-Rated Courses", low_course_count)
    o3.metric("Low-Rated Professors", low_professor_count)
    o4.metric("Large Rating Gaps", big_gap_count)

    st.divider()

    # -----------------------------
    # Compact charts
    # -----------------------------
    left, right = st.columns(2)

    with left:
        compact_courses = (
            course_summary[course_summary["response_count"] >= min_responses]
            .sort_values("avg_course_rating", ascending=True)
            .head(6)
        )

        fig = px.bar(
            compact_courses,
            x="avg_course_rating",
            y="CourseIdentifier",
            orientation="h",
            hover_data=[
                "CourseTitle",
                "Department",
                "College",
                "response_count",
                "professor_count",
            ],
            title="Courses Needing Review",
        )

        fig.update_layout(
            height=300,
            margin=dict(l=10, r=10, t=45, b=10),
            yaxis={"categoryorder": "total ascending"},
            showlegend=False,
        )

        st.plotly_chart(fig, use_container_width=True)

    with right:
        compact_professors = (
            professor_summary[professor_summary["response_count"] >= min_responses]
            .sort_values("avg_professor_rating", ascending=True)
            .head(6)
        )

        fig = px.bar(
            compact_professors,
            x="avg_professor_rating",
            y="ProfessorDisplay",
            orientation="h",
            hover_data=[
                "Department",
                "College",
                "response_count",
                "course_count",
            ],
            title="Professors Needing Review",
        )

        fig.update_layout(
            height=300,
            margin=dict(l=10, r=10, t=45, b=10),
            yaxis={"categoryorder": "total ascending"},
            showlegend=False,
        )

        st.plotly_chart(fig, use_container_width=True)

    st.divider()

    # -----------------------------
    # Compact insight tables
    # -----------------------------
    t1, t2 = st.columns(2)

    with t1:
        st.markdown("#### Course Review Candidates")

        course_review_table = (
            course_summary[course_summary["response_count"] >= min_responses]
            .sort_values(["avg_course_rating", "response_count"], ascending=[True, False])
            .head(8)
        )

        st.dataframe(
            course_review_table[
                [
                    "CourseIdentifier",
                    "CourseTitle",
                    "Department",
                    "avg_course_rating",
                    "avg_professor_rating",
                    "rating_gap",
                    "response_count",
                ]
            ],
            use_container_width=True,
            height=260,
        )

    with t2:
        st.markdown("#### Professor-Course Fit Issues")

        fit_issue_table = (
            professor_course[professor_course["response_count"] >= min_responses]
            .sort_values(["course_rating", "professor_rating"], ascending=[True, True])
            .head(8)
        )

        st.dataframe(
            fit_issue_table[
                [
                    "ProfessorDisplay",
                    "CourseIdentifier",
                    "CourseTitle",
                    "professor_rating",
                    "course_rating",
                    "rating_gap",
                    "response_count",
                    "risk_status",
                ]
            ],
            use_container_width=True,
            height=260,
        )

    st.divider()

    # -----------------------------
    # Department compact summary
    # -----------------------------
    st.markdown("#### Department Summary")

    dept_table = (
        department_summary
        .sort_values("avg_course_rating", ascending=True)
        .head(10)
    )

    st.dataframe(
        dept_table[
            [
                "Department",
                "College",
                "avg_course_rating",
                "avg_professor_rating",
                "response_count",
                "course_count",
                "professor_count",
            ]
        ],
        use_container_width=True,
        height=260,
    )


    
# -------------------------------------------------
# Professor → Courses
# -------------------------------------------------
with tab2:
    st.markdown('<div class="section-title">Professor → Courses Taught</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="section-note">Select a professor to see every course they taught and the course/professor ratings.</div>',
        unsafe_allow_html=True,
    )

    professor_pick = st.selectbox(
        "Choose Professor",
        sorted(filtered["ProfessorDisplay"].dropna().unique()),
        key="professor_pick",
    )

    prof_courses = professor_course[
        professor_course["ProfessorDisplay"] == professor_pick
    ].sort_values("course_rating", ascending=True)

    p1, p2, p3, p4 = st.columns(4)

    p1.metric("Courses Taught", prof_courses["CourseIdentifier"].nunique())
    p2.metric("Total Responses", int(prof_courses["response_count"].sum()))
    p3.metric("Avg Professor Rating", round(prof_courses["professor_rating"].mean(), 2))
    p4.metric("Avg Course Rating", round(prof_courses["course_rating"].mean(), 2))

    fig = px.bar(
        prof_courses,
        x="CourseIdentifier",
        y=["professor_rating", "course_rating"],
        barmode="group",
        hover_data=["CourseTitle", "Department", "College", "response_count"],
        title=f"Courses Taught by {professor_pick}",
    )
    fig.update_layout(height=500)
    st.plotly_chart(fig, use_container_width=True)

    st.dataframe(
        prof_courses[
            [
                "CourseIdentifier",
                "CourseTitle",
                "Department",
                "College",
                "DeliveryCode",
                "professor_rating",
                "course_rating",
                "rating_gap",
                "response_count",
                "risk_status",
            ]
        ],
        use_container_width=True,
        height=420,
    )


# -------------------------------------------------
# Course → Professors
# -------------------------------------------------
with tab3:
    st.markdown('<div class="section-title">Course → Professors Who Taught It</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="section-note">Select a course to see which professors taught it and their ratings.</div>',
        unsafe_allow_html=True,
    )

    course_pick = st.selectbox(
        "Choose Course",
        sorted(filtered["CourseIdentifier"].dropna().unique()),
        key="course_pick",
    )

    course_professors = professor_course[
        professor_course["CourseIdentifier"] == course_pick
    ].sort_values("professor_rating", ascending=True)

    selected_course_title = (
        course_professors["CourseTitle"].iloc[0]
        if not course_professors.empty
        else ""
    )

    st.markdown(f"### {course_pick} — {selected_course_title}")

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("Professors", course_professors["ProfessorDisplay"].nunique())
    c2.metric("Total Responses", int(course_professors["response_count"].sum()))
    c3.metric("Avg Course Rating", round(course_professors["course_rating"].mean(), 2))
    c4.metric("Avg Professor Rating", round(course_professors["professor_rating"].mean(), 2))

    fig = px.bar(
        course_professors,
        x="ProfessorDisplay",
        y=["professor_rating", "course_rating"],
        barmode="group",
        hover_data=["Department", "College", "response_count"],
        title=f"Professor Ratings for {course_pick}",
    )
    fig.update_layout(height=500)
    st.plotly_chart(fig, use_container_width=True)

    st.dataframe(
        course_professors[
            [
                "ProfessorDisplay",
                "CourseIdentifier",
                "CourseTitle",
                "Department",
                "College",
                "professor_rating",
                "course_rating",
                "rating_gap",
                "response_count",
                "risk_status",
            ]
        ],
        use_container_width=True,
        height=420,
    )


# -------------------------------------------------
# Professor/Course Matrix
# -------------------------------------------------
with tab4:
    st.markdown('<div class="section-title">Professor/Course Matrix</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="section-note">Heatmap of professor rating by professor and course.</div>',
        unsafe_allow_html=True,
    )

    matrix_metric = st.radio(
        "Matrix metric",
        ["professor_rating", "course_rating", "rating_gap", "response_count"],
        horizontal=True,
    )

    matrix_df = professor_course.copy()

    pivot = matrix_df.pivot_table(
        index="ProfessorDisplay",
        columns="CourseIdentifier",
        values=matrix_metric,
        aggfunc="mean",
    )

    fig = px.imshow(
        pivot,
        aspect="auto",
        title=f"{matrix_metric} Matrix",
    )
    fig.update_layout(height=650)
    st.plotly_chart(fig, use_container_width=True)

    st.dataframe(
        professor_course.sort_values(["ProfessorDisplay", "CourseIdentifier"]),
        use_container_width=True,
        height=420,
    )


# -------------------------------------------------
# Risk + Gaps
# -------------------------------------------------
with tab5:
    st.markdown('<div class="section-title">Risk + Rating Gap Analysis</div>', unsafe_allow_html=True)

    risk_df = professor_course[
        professor_course["response_count"] >= min_responses
    ].copy()

    fig = px.scatter(
        risk_df,
        x="course_rating",
        y="professor_rating",
        size="response_count",
        color="risk_status",
        hover_name="CourseIdentifier",
        hover_data=[
            "ProfessorDisplay",
            "CourseTitle",
            "Department",
            "College",
            "rating_gap",
            "response_count",
        ],
        title="Course Rating vs Professor Rating",
    )
    fig.update_layout(height=600)
    st.plotly_chart(fig, use_container_width=True)

    st.markdown('<div class="section-title">Biggest Gaps</div>', unsafe_allow_html=True)

    gap_table = risk_df.sort_values("rating_gap", ascending=False)

    st.dataframe(
        gap_table[
            [
                "ProfessorDisplay",
                "CourseIdentifier",
                "CourseTitle",
                "Department",
                "College",
                "professor_rating",
                "course_rating",
                "rating_gap",
                "response_count",
                "risk_status",
            ]
        ],
        use_container_width=True,
        height=420,
    )

    st.markdown('<div class="section-title">Department Summary</div>', unsafe_allow_html=True)

    st.dataframe(
        department_summary.sort_values("avg_course_rating", ascending=True),
        use_container_width=True,
        height=360,
    )


# -------------------------------------------------
# Ask Database
# -------------------------------------------------
with tab6:
    st.markdown('<div class="section-title">Ask the Course Evaluation Database</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="section-note">Gemini generates SQL against the privacy-safe bronze_cleaned_data table only.</div>',
        unsafe_allow_html=True,
    )

    examples = [
        "Which professor aliases have the lowest instructor ratings?",
        "Which courses have the lowest course ratings?",
        "Which courses have the biggest gap between instructor rating and course rating?",
        "Show average course rating by department.",
        "Show average professor rating by college.",
        "Which course has the most evaluations?",
    ]

    example = st.selectbox("Example questions", [""] + examples)

    question = st.text_input(
        "Ask a question",
        value=example,
        placeholder="Example: Which course has the lowest rating?",
    )

    if st.button("Ask Database"):
        if question.strip():
            try:
                sql, result_df = ask_database(question)

                if "Instructor_alias" in result_df.columns:
                    name_map = df[["Instructor_alias", "ProfessorDisplay"]].drop_duplicates()

                    result_df = result_df.merge(
                        name_map,
                        on="Instructor_alias",
                        how="left"
                    )

                st.subheader("Generated SQL")
                st.code(sql, language="sql")

                st.subheader("Result")
                st.dataframe(result_df, use_container_width=True)

            except Exception as e:
                st.error(str(e))