import pandas as pd
from sqlalchemy import create_engine

DATABASE_URL = "postgresql://postgres:admin@localhost:5432/course_eval_ai"

engine = create_engine(DATABASE_URL)

df = pd.read_sql('SELECT * FROM bronze_cleaned_data', engine)

output_file = "bronze_cleaned_data.csv"
df.to_csv(output_file, index=False)

print(f"Saved {len(df)} rows to {output_file}")