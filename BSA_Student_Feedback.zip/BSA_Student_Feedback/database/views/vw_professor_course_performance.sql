CREATE OR REPLACE VIEW vw_professor_course_performance AS
SELECT
    "Instructor_alias",
    "CourseIdentifier",
    "CourseTitle",
    "Department",
    "College",
    "DeliveryCode",

    ROUND(AVG(row_instructor_rating)::numeric, 2) AS professor_rating,
    ROUND(AVG(row_course_rating)::numeric, 2) AS course_rating,

    ROUND(
        (AVG(row_instructor_rating) - AVG(row_course_rating))::numeric,
        2
    ) AS rating_gap,

    COUNT(*) AS response_count,

    ROUND(STDDEV_SAMP(row_instructor_rating)::numeric, 2) AS professor_rating_stddev,
    ROUND(STDDEV_SAMP(row_course_rating)::numeric, 2) AS course_rating_stddev,

    ROUND(
        PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY row_instructor_rating)::numeric,
        2
    ) AS professor_rating_median,

    ROUND(
        PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY row_course_rating)::numeric,
        2
    ) AS course_rating_median,

    CASE
        WHEN COUNT(*) < 3 THEN 'INSUFFICIENT SAMPLE'
        WHEN COUNT(*) BETWEEN 3 AND 4 THEN 'LOW CONFIDENCE'
        WHEN AVG(row_course_rating) < 3.5 OR AVG(row_instructor_rating) < 3.5 THEN 'REVIEW'
        WHEN STDDEV_SAMP(row_course_rating) >= 1.25
          OR STDDEV_SAMP(row_instructor_rating) >= 1.25 THEN 'MIXED FEEDBACK'
        ELSE 'OK'
    END AS risk_status

FROM vw_bronze_row_scores
GROUP BY
    "Instructor_alias",
    "CourseIdentifier",
    "CourseTitle",
    "Department",
    "College",
    "DeliveryCode";