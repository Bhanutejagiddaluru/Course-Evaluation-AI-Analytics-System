CREATE OR REPLACE VIEW vw_bronze_row_scores AS
SELECT
    "Instructor_alias",
    "SessionName",
    "CourseIdentifier",
    "CourseTitle",
    "Department",
    "College",
    "DeliveryCode",
    "AlternateIdentifier",
    "CampusCode",
    "InstructorType",

    "i1", "i2", "i3", "i4", "i5", "i6", "i7",
    "c1", "c2", "c3", "c4", "c5",

    (
        COALESCE("i1", 0) +
        COALESCE("i2", 0) +
        COALESCE("i3", 0) +
        COALESCE("i4", 0) +
        COALESCE("i5", 0) +
        COALESCE("i6", 0) +
        COALESCE("i7", 0)
    )::numeric
    /
    NULLIF(
        ("i1" IS NOT NULL)::int +
        ("i2" IS NOT NULL)::int +
        ("i3" IS NOT NULL)::int +
        ("i4" IS NOT NULL)::int +
        ("i5" IS NOT NULL)::int +
        ("i6" IS NOT NULL)::int +
        ("i7" IS NOT NULL)::int,
        0
    ) AS row_instructor_rating,

    (
        COALESCE("c1", 0) +
        COALESCE("c2", 0) +
        COALESCE("c3", 0) +
        COALESCE("c4", 0) +
        COALESCE("c5", 0)
    )::numeric
    /
    NULLIF(
        ("c1" IS NOT NULL)::int +
        ("c2" IS NOT NULL)::int +
        ("c3" IS NOT NULL)::int +
        ("c4" IS NOT NULL)::int +
        ("c5" IS NOT NULL)::int,
        0
    ) AS row_course_rating,

    (
        ("i1" IS NOT NULL)::int +
        ("i2" IS NOT NULL)::int +
        ("i3" IS NOT NULL)::int +
        ("i4" IS NOT NULL)::int +
        ("i5" IS NOT NULL)::int +
        ("i6" IS NOT NULL)::int +
        ("i7" IS NOT NULL)::int
    ) AS answered_instructor_question_count,

    (
        ("c1" IS NOT NULL)::int +
        ("c2" IS NOT NULL)::int +
        ("c3" IS NOT NULL)::int +
        ("c4" IS NOT NULL)::int +
        ("c5" IS NOT NULL)::int
    ) AS answered_course_question_count

FROM bronze_cleaned_data;