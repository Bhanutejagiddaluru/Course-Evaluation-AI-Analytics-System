CREATE OR REPLACE VIEW vw_course_alerts AS
SELECT
    "CourseIdentifier",
    "CourseTitle",
    "Department",
    "College",
    "DeliveryCode",

    avg_course_rating,
    avg_instructor_rating,
    rating_gap,

    response_count,
    instructor_count,

    course_rating_stddev,
    instructor_rating_stddev,
    course_rating_median,
    instructor_rating_median,

    course_vs_department_delta,
    instructor_vs_department_delta,

    risk_status,

    CASE
        WHEN risk_status = 'INSUFFICIENT SAMPLE' THEN 5
        WHEN risk_status = 'REVIEW' THEN 4
        WHEN risk_status = 'MIXED FEEDBACK' THEN 3
        WHEN risk_status = 'LOW CONFIDENCE' THEN 2
        ELSE 1
    END AS alert_priority

FROM vw_course_performance
WHERE risk_status <> 'OK'
ORDER BY
    alert_priority DESC,
    avg_course_rating ASC,
    response_count DESC;