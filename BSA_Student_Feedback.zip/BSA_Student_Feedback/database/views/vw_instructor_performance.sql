CREATE OR REPLACE VIEW vw_instructor_performance AS
WITH instructor_group AS (
    SELECT
        "Instructor_alias",
        "Department",
        "College",

        ROUND(AVG(row_instructor_rating)::numeric, 2) AS avg_instructor_rating,
        ROUND(AVG(row_course_rating)::numeric, 2) AS avg_course_rating,

        ROUND(
            (AVG(row_instructor_rating) - AVG(row_course_rating))::numeric,
            2
        ) AS rating_gap,

        COUNT(*) AS response_count,
        COUNT(DISTINCT "CourseIdentifier") AS course_count,

        ROUND(STDDEV_SAMP(row_instructor_rating)::numeric, 2) AS instructor_rating_stddev,
        ROUND(STDDEV_SAMP(row_course_rating)::numeric, 2) AS course_rating_stddev,

        ROUND(
            PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY row_instructor_rating)::numeric,
            2
        ) AS instructor_rating_median,

        ROUND(
            PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY row_course_rating)::numeric,
            2
        ) AS course_rating_median

    FROM vw_bronze_row_scores
    GROUP BY
        "Instructor_alias",
        "Department",
        "College"
),

department_baseline AS (
    SELECT
        "Department",
        "College",
        ROUND(AVG(row_instructor_rating)::numeric, 2) AS department_avg_instructor_rating,
        ROUND(AVG(row_course_rating)::numeric, 2) AS department_avg_course_rating
    FROM vw_bronze_row_scores
    GROUP BY
        "Department",
        "College"
)

SELECT
    i."Instructor_alias",
    i."Department",
    i."College",

    i.avg_instructor_rating,
    i.avg_course_rating,
    i.rating_gap,

    i.response_count,
    i.course_count,

    i.instructor_rating_stddev,
    i.course_rating_stddev,
    i.instructor_rating_median,
    i.course_rating_median,

    d.department_avg_instructor_rating,
    d.department_avg_course_rating,

    ROUND(
        (i.avg_instructor_rating - d.department_avg_instructor_rating)::numeric,
        2
    ) AS instructor_vs_department_delta,

    ROUND(
        (i.avg_course_rating - d.department_avg_course_rating)::numeric,
        2
    ) AS course_vs_department_delta,

    PERCENT_RANK() OVER (
        PARTITION BY i."Department", i."College"
        ORDER BY i.avg_instructor_rating
    ) AS instructor_percentile_in_department,

    CASE
        WHEN i.response_count < 3 THEN 'INSUFFICIENT SAMPLE'
        WHEN i.response_count BETWEEN 3 AND 4 THEN 'LOW CONFIDENCE'
        WHEN i.avg_instructor_rating < 3.5 THEN 'REVIEW'
        WHEN i.instructor_rating_stddev >= 1.25 THEN 'MIXED FEEDBACK'
        ELSE 'OK'
    END AS risk_status

FROM instructor_group i
LEFT JOIN department_baseline d
    ON i."Department" = d."Department"
   AND i."College" = d."College";