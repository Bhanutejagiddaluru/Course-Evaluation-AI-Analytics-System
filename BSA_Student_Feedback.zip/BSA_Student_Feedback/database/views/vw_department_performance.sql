CREATE OR REPLACE VIEW vw_department_performance AS
SELECT
    "Department",
    "College",

    ROUND(AVG(row_course_rating)::numeric, 2) AS avg_course_rating,
    ROUND(AVG(row_instructor_rating)::numeric, 2) AS avg_instructor_rating,

    ROUND(
        (AVG(row_instructor_rating) - AVG(row_course_rating))::numeric,
        2
    ) AS rating_gap,

    COUNT(*) AS response_count,
    COUNT(DISTINCT "CourseIdentifier") AS course_count,
    COUNT(DISTINCT "Instructor_alias") AS instructor_count,

    ROUND(STDDEV_SAMP(row_course_rating)::numeric, 2) AS course_rating_stddev,
    ROUND(STDDEV_SAMP(row_instructor_rating)::numeric, 2) AS instructor_rating_stddev,

    ROUND(
        PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY row_course_rating)::numeric,
        2
    ) AS course_rating_median,

    ROUND(
        PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY row_instructor_rating)::numeric,
        2
    ) AS instructor_rating_median,

    CASE
        WHEN COUNT(*) < 3 THEN 'INSUFFICIENT SAMPLE'
        WHEN COUNT(*) BETWEEN 3 AND 4 THEN 'LOW CONFIDENCE'
        WHEN AVG(row_course_rating) < 3.5 THEN 'REVIEW'
        WHEN STDDEV_SAMP(row_course_rating) >= 1.25 THEN 'MIXED FEEDBACK'
        ELSE 'OK'
    END AS risk_status

FROM vw_bronze_row_scores
GROUP BY
    "Department",
    "College";