CREATE OR REPLACE VIEW vw_course_performance AS
WITH course_group AS (
    SELECT
        "CourseIdentifier",
        "CourseTitle",
        "Department",
        "College",
        "DeliveryCode",

        ROUND(AVG(row_course_rating)::numeric, 2) AS avg_course_rating,
        ROUND(AVG(row_instructor_rating)::numeric, 2) AS avg_instructor_rating,

        ROUND(
            (AVG(row_instructor_rating) - AVG(row_course_rating))::numeric,
            2
        ) AS rating_gap,

        COUNT(*) AS response_count,
        COUNT(row_course_rating) AS course_rating_response_count,
        COUNT(row_instructor_rating) AS instructor_rating_response_count,
        COUNT(DISTINCT "Instructor_alias") AS instructor_count,

        ROUND(STDDEV_SAMP(row_course_rating)::numeric, 2) AS course_rating_stddev,
        ROUND(STDDEV_SAMP(row_instructor_rating)::numeric, 2) AS instructor_rating_stddev,

        ROUND(
            PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY row_course_rating)::numeric,
            2
        ) AS course_rating_median,

        ROUND(
            PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY row_instructor_rating)::numeric,
            2
        ) AS instructor_rating_median

    FROM vw_bronze_row_scores
    GROUP BY
        "CourseIdentifier",
        "CourseTitle",
        "Department",
        "College",
        "DeliveryCode"
),

department_baseline AS (
    SELECT
        "Department",
        "College",
        ROUND(AVG(row_course_rating)::numeric, 2) AS department_avg_course_rating,
        ROUND(AVG(row_instructor_rating)::numeric, 2) AS department_avg_instructor_rating
    FROM vw_bronze_row_scores
    GROUP BY
        "Department",
        "College"
)

SELECT
    c."CourseIdentifier",
    c."CourseTitle",
    c."Department",
    c."College",
    c."DeliveryCode",

    c.avg_course_rating,
    c.avg_instructor_rating,
    c.rating_gap,

    c.response_count,
    c.course_rating_response_count,
    c.instructor_rating_response_count,
    c.instructor_count,

    c.course_rating_stddev,
    c.instructor_rating_stddev,
    c.course_rating_median,
    c.instructor_rating_median,

    d.department_avg_course_rating,
    d.department_avg_instructor_rating,

    ROUND(
        (c.avg_course_rating - d.department_avg_course_rating)::numeric,
        2
    ) AS course_vs_department_delta,

    ROUND(
        (c.avg_instructor_rating - d.department_avg_instructor_rating)::numeric,
        2
    ) AS instructor_vs_department_delta,

    CASE
        WHEN c.response_count < 3 THEN 'INSUFFICIENT SAMPLE'
        WHEN c.response_count BETWEEN 3 AND 4 THEN 'LOW CONFIDENCE'
        WHEN c.avg_course_rating < 3.5 THEN 'REVIEW'
        WHEN c.course_rating_stddev >= 1.25 THEN 'MIXED FEEDBACK'
        ELSE 'OK'
    END AS risk_status

FROM course_group c
LEFT JOIN department_baseline d
    ON c."Department" = d."Department"
   AND c."College" = d."College";