CREATE SCHEMA IF NOT EXISTS silver;

DROP TABLE IF EXISTS silver.fact_evaluation_response CASCADE;
DROP TABLE IF EXISTS silver.dim_course CASCADE;
DROP TABLE IF EXISTS silver.dim_instructor CASCADE;
DROP TABLE IF EXISTS silver.dim_session CASCADE;
DROP TABLE IF EXISTS silver.dim_delivery CASCADE;
DROP TABLE IF EXISTS silver.dim_org CASCADE;

CREATE TABLE silver.dim_course (
    course_key SERIAL PRIMARY KEY,
    course_nk TEXT UNIQUE NOT NULL,
    course_identifier TEXT,
    course_title TEXT,
    alternate_identifier TEXT
);

CREATE TABLE silver.dim_instructor (
    instructor_key SERIAL PRIMARY KEY,
    instructor_alias TEXT UNIQUE NOT NULL,
    instructor_type TEXT
);

CREATE TABLE silver.dim_session (
    session_key SERIAL PRIMARY KEY,
    session_name TEXT UNIQUE NOT NULL
);

CREATE TABLE silver.dim_delivery (
    delivery_key SERIAL PRIMARY KEY,
    delivery_nk TEXT UNIQUE NOT NULL,
    delivery_code TEXT,
    campus_code TEXT
);

CREATE TABLE silver.dim_org (
    org_key SERIAL PRIMARY KEY,
    org_nk TEXT UNIQUE NOT NULL,
    department TEXT,
    college TEXT
);

CREATE TABLE silver.fact_evaluation_response (
    response_id BIGSERIAL PRIMARY KEY,

    course_key INT NOT NULL REFERENCES silver.dim_course(course_key),
    instructor_key INT NOT NULL REFERENCES silver.dim_instructor(instructor_key),
    session_key INT NOT NULL REFERENCES silver.dim_session(session_key),
    delivery_key INT NOT NULL REFERENCES silver.dim_delivery(delivery_key),
    org_key INT NOT NULL REFERENCES silver.dim_org(org_key),

    i1 NUMERIC,
    i2 NUMERIC,
    i3 NUMERIC,
    i4 NUMERIC,
    i5 NUMERIC,
    i6 NUMERIC,
    i7 NUMERIC,

    c1 NUMERIC,
    c2 NUMERIC,
    c3 NUMERIC,
    c4 NUMERIC,
    c5 NUMERIC,

    row_instructor_rating NUMERIC,
    row_course_rating NUMERIC,
    rating_gap NUMERIC,

    answered_instructor_question_count INT,
    answered_course_question_count INT,

    source_table TEXT DEFAULT 'bronze_cleaned_data',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_fact_course_key ON silver.fact_evaluation_response(course_key);
CREATE INDEX idx_fact_instructor_key ON silver.fact_evaluation_response(instructor_key);
CREATE INDEX idx_fact_session_key ON silver.fact_evaluation_response(session_key);
CREATE INDEX idx_fact_delivery_key ON silver.fact_evaluation_response(delivery_key);
CREATE INDEX idx_fact_org_key ON silver.fact_evaluation_response(org_key);