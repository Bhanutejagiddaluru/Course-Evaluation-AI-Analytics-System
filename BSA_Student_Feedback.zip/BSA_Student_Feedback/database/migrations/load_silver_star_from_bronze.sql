TRUNCATE TABLE
    silver.fact_evaluation_response,
    silver.dim_course,
    silver.dim_instructor,
    silver.dim_session,
    silver.dim_delivery,
    silver.dim_org
RESTART IDENTITY CASCADE;


-- 1. Course dimension
INSERT INTO silver.dim_course (
    course_nk,
    course_identifier,
    course_title,
    alternate_identifier
)
SELECT DISTINCT
    md5(
        concat_ws(
            '|',
            COALESCE("CourseIdentifier", 'UNKNOWN'),
            COALESCE("CourseTitle", 'UNKNOWN'),
            COALESCE("AlternateIdentifier", 'UNKNOWN')
        )
    ) AS course_nk,
    "CourseIdentifier",
    "CourseTitle",
    "AlternateIdentifier"
FROM bronze_cleaned_data;


-- 2. Instructor dimension
INSERT INTO silver.dim_instructor (
    instructor_alias,
    instructor_type
)
SELECT
    COALESCE("Instructor_alias", 'UNKNOWN') AS instructor_alias,
    MAX("InstructorType") AS instructor_type
FROM bronze_cleaned_data
GROUP BY
    COALESCE("Instructor_alias", 'UNKNOWN');


-- 3. Session dimension
INSERT INTO silver.dim_session (
    session_name
)
SELECT DISTINCT
    COALESCE("SessionName", 'UNKNOWN') AS session_name
FROM bronze_cleaned_data;


-- 4. Delivery dimension
INSERT INTO silver.dim_delivery (
    delivery_nk,
    delivery_code,
    campus_code
)
SELECT DISTINCT
    md5(
        concat_ws(
            '|',
            COALESCE("DeliveryCode", 'UNKNOWN'),
            COALESCE("CampusCode", 'UNKNOWN')
        )
    ) AS delivery_nk,
    "DeliveryCode",
    "CampusCode"
FROM bronze_cleaned_data;


-- 5. Organization dimension
INSERT INTO silver.dim_org (
    org_nk,
    department,
    college
)
SELECT DISTINCT
    md5(
        concat_ws(
            '|',
            COALESCE("Department", 'UNKNOWN'),
            COALESCE("College", 'UNKNOWN')
        )
    ) AS org_nk,
    "Department",
    "College"
FROM bronze_cleaned_data;


-- 6. Fact table
WITH scored AS (
    SELECT
        b.*,

        (
            COALESCE(b."i1", 0) +
            COALESCE(b."i2", 0) +
            COALESCE(b."i3", 0) +
            COALESCE(b."i4", 0) +
            COALESCE(b."i5", 0) +
            COALESCE(b."i6", 0) +
            COALESCE(b."i7", 0)
        )::numeric
        /
        NULLIF(
            (b."i1" IS NOT NULL)::int +
            (b."i2" IS NOT NULL)::int +
            (b."i3" IS NOT NULL)::int +
            (b."i4" IS NOT NULL)::int +
            (b."i5" IS NOT NULL)::int +
            (b."i6" IS NOT NULL)::int +
            (b."i7" IS NOT NULL)::int,
            0
        ) AS row_instructor_rating,

        (
            COALESCE(b."c1", 0) +
            COALESCE(b."c2", 0) +
            COALESCE(b."c3", 0) +
            COALESCE(b."c4", 0) +
            COALESCE(b."c5", 0)
        )::numeric
        /
        NULLIF(
            (b."c1" IS NOT NULL)::int +
            (b."c2" IS NOT NULL)::int +
            (b."c3" IS NOT NULL)::int +
            (b."c4" IS NOT NULL)::int +
            (b."c5" IS NOT NULL)::int,
            0
        ) AS row_course_rating,

        (
            (b."i1" IS NOT NULL)::int +
            (b."i2" IS NOT NULL)::int +
            (b."i3" IS NOT NULL)::int +
            (b."i4" IS NOT NULL)::int +
            (b."i5" IS NOT NULL)::int +
            (b."i6" IS NOT NULL)::int +
            (b."i7" IS NOT NULL)::int
        ) AS answered_instructor_question_count,

        (
            (b."c1" IS NOT NULL)::int +
            (b."c2" IS NOT NULL)::int +
            (b."c3" IS NOT NULL)::int +
            (b."c4" IS NOT NULL)::int +
            (b."c5" IS NOT NULL)::int
        ) AS answered_course_question_count

    FROM bronze_cleaned_data b
)

INSERT INTO silver.fact_evaluation_response (
    course_key,
    instructor_key,
    session_key,
    delivery_key,
    org_key,

    i1, i2, i3, i4, i5, i6, i7,
    c1, c2, c3, c4, c5,

    row_instructor_rating,
    row_course_rating,
    rating_gap,

    answered_instructor_question_count,
    answered_course_question_count
)
SELECT
    dc.course_key,
    di.instructor_key,
    ds.session_key,
    dd.delivery_key,
    doo.org_key,

    s."i1", s."i2", s."i3", s."i4", s."i5", s."i6", s."i7",
    s."c1", s."c2", s."c3", s."c4", s."c5",

    ROUND(s.row_instructor_rating, 2) AS row_instructor_rating,
    ROUND(s.row_course_rating, 2) AS row_course_rating,

    ROUND(
        (s.row_instructor_rating - s.row_course_rating),
        2
    ) AS rating_gap,

    s.answered_instructor_question_count,
    s.answered_course_question_count

FROM scored s

JOIN silver.dim_course dc
    ON dc.course_nk = md5(
        concat_ws(
            '|',
            COALESCE(s."CourseIdentifier", 'UNKNOWN'),
            COALESCE(s."CourseTitle", 'UNKNOWN'),
            COALESCE(s."AlternateIdentifier", 'UNKNOWN')
        )
    )

JOIN silver.dim_instructor di
    ON di.instructor_alias = COALESCE(s."Instructor_alias", 'UNKNOWN')

JOIN silver.dim_session ds
    ON ds.session_name = COALESCE(s."SessionName", 'UNKNOWN')

JOIN silver.dim_delivery dd
    ON dd.delivery_nk = md5(
        concat_ws(
            '|',
            COALESCE(s."DeliveryCode", 'UNKNOWN'),
            COALESCE(s."CampusCode", 'UNKNOWN')
        )
    )

JOIN silver.dim_org doo
    ON doo.org_nk = md5(
        concat_ws(
            '|',
            COALESCE(s."Department", 'UNKNOWN'),
            COALESCE(s."College", 'UNKNOWN')
        )
    );