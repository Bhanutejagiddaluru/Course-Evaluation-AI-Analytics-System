DROP TABLE IF EXISTS ai_insights;

CREATE TABLE ai_insights (
    insight_id SERIAL PRIMARY KEY,
    evaluation_id INTEGER,
    comment_type TEXT,
    sentiment TEXT,
    topic_tag TEXT,
    severity TEXT,
    emergency_flag BOOLEAN,
    recommended_action TEXT
);