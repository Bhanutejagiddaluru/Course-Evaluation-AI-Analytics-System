SELECT
    "InstructorName",
    ROUND(AVG(i1), 2) AS avg_instructor_rating
FROM evaluations
GROUP BY "InstructorName"
ORDER BY avg_instructor_rating ASC
LIMIT 10;