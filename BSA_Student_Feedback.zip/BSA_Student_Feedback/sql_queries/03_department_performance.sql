SELECT
    "CourseIdentifier",
    COUNT(*) AS low_score_count
FROM evaluations
WHERE c1 < 3
GROUP BY "CourseIdentifier"
ORDER BY low_score_count DESC;