CREATE TABLE instructor_performance AS
SELECT
    "InstructorName",
    ROUND(AVG(i1), 2) AS avg_rating
FROM evaluations
GROUP BY "InstructorName";