SELECT
    "CourseIdentifier",
    ROUND(AVG(c1), 2) AS avg_course_rating
FROM evaluations
GROUP BY "CourseIdentifier"
ORDER BY avg_course_rating DESC
LIMIT 10;