SELECT
    "InstructorName",
    ROUND(AVG(i1), 2) AS avg_rating
FROM evaluations
GROUP BY "InstructorName"
ORDER BY avg_rating DESC
LIMIT 10;