SELECT
    i1,
    COUNT(*) AS total
FROM evaluations
GROUP BY i1
ORDER BY i1;