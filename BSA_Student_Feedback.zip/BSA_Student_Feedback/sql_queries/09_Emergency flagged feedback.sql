SELECT *
FROM ai_insights
WHERE emergency_flag = true;