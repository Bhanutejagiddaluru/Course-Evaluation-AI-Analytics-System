DROP TABLE IF EXISTS course_performance;

CREATE TABLE course_performance AS
SELECT
    "CourseIdentifier",
    "CourseTitle",
    "College",
    ROUND(AVG(c1), 2) AS avg_course_rating,
    COUNT(*) AS response_count
FROM evaluations
GROUP BY
    "CourseIdentifier",
    "CourseTitle",
    "College"
ORDER BY avg_course_rating ASC;