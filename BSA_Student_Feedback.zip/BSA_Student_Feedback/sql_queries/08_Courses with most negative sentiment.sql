SELECT
    topic_tag,
    COUNT(*) AS issue_count
FROM ai_insights
WHERE sentiment = 'negative'
GROUP BY topic_tag
ORDER BY issue_count DESC;