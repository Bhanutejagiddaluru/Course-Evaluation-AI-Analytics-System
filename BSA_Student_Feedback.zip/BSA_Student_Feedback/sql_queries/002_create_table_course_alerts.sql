DROP TABLE IF EXISTS course_alerts;

CREATE TABLE course_alerts AS
SELECT
    "CourseIdentifier",
    "CourseTitle",
    "College",

    ROUND(AVG(c1), 2) AS avg_course_rating,

    COUNT(*) AS response_count,

    CASE
        WHEN AVG(c1) < 3 THEN 'LOW COURSE RATING'
        WHEN COUNT(*) < 3 THEN 'LOW RESPONSE COUNT'
        ELSE 'OK'
    END AS alert_status

FROM evaluations

GROUP BY
    "CourseIdentifier",
    "CourseTitle",
    "College";