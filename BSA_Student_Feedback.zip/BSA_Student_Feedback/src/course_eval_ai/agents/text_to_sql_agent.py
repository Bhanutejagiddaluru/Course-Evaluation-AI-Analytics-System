import re
import pandas as pd
from sqlalchemy import create_engine, text
from google import genai


GEMINI_API_KEY = "Replace with your api"

DATABASE_URL = "Replace with your database url"

ALLOWED_TABLES = [
    "bronze_cleaned_data",
]

SCHEMA_CONTEXT = """
You are a Text-to-SQL assistant for a university course evaluation database.

Only generate PostgreSQL SELECT queries.

Allowed table:

1. bronze_cleaned_data
Columns:
- Instructor_alias
- SessionName
- CourseIdentifier
- CourseTitle
- Department
- College
- DeliveryCode
- AlternateIdentifier
- CampusCode
- InstructorType
- i1, i2, i3, i4, i5, i6, i7
- c1, c2, c3, c4, c5

Rules:
- Only write PostgreSQL SELECT queries.
- Only use the bronze_cleaned_data table.
- Never use INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE, GRANT, REVOKE.
- Never query bronze_instructor_alias_map.
- Never query raw_uploaded_files.
- Never query bronze_cleaned_feedback.
- Never query bronze_identity_protected_evaluations.
- Always use double quotes around mixed-case column names.
- When calculating averages, ignore NULL values.
- For course ratings, use c1-c5.
- For instructor ratings, use i1-i7.
- Include response counts when ranking courses or instructors.
- Limit results to 20 rows unless the user asks otherwise.
Return only SQL. No explanation. No markdown.
"""


def get_engine():
    return create_engine(DATABASE_URL)


def is_safe_sql(sql: str) -> bool:
    sql_lower = sql.lower().strip()
    sql_lower = sql_lower.rstrip(";").strip()

    if not sql_lower.startswith("select"):
        return False

    if ";" in sql_lower:
        return False

    forbidden = [
        "insert", "update", "delete", "drop", "alter", "truncate",
        "create", "grant", "revoke", "copy", "execute", "call"
    ]

    for word in forbidden:
        if re.search(rf"\b{word}\b", sql_lower):
            return False

    blocked_tables = [
        "bronze_instructor_alias_map",
        "raw_uploaded_files",
        "bronze_cleaned_feedback",
        "bronze_identity_protected_evaluations",
        "bronze_comment_queue",
        "bronze_redacted_comments",
    ]

    for table in blocked_tables:
        if table.lower() in sql_lower:
            return False

    allowed_found = any(
        table.lower() in sql_lower for table in ALLOWED_TABLES
    )

    return allowed_found


def generate_sql(question: str) -> str:
    client = genai.Client(api_key=GEMINI_API_KEY)

    prompt = f"""
{SCHEMA_CONTEXT}

User question:
{question}

Return only PostgreSQL SQL.
No markdown.
No explanation.
"""

    response = client.models.generate_content(
        model="gemini-3-flash-preview",
        contents=prompt,
    )

    sql = response.text.strip()
    sql = sql.replace("```sql", "").replace("```", "").strip()
    sql = sql.rstrip(";").strip()

    return sql


def run_sql(sql: str) -> pd.DataFrame:
    if not is_safe_sql(sql):
        raise ValueError(f"Unsafe SQL blocked:\n{sql}")

    engine = get_engine()

    with engine.connect() as conn:
        df = pd.read_sql(text(sql), conn)

    return df


def ask_database(question: str):
    sql = generate_sql(question)
    result_df = run_sql(sql)

    return sql, result_df