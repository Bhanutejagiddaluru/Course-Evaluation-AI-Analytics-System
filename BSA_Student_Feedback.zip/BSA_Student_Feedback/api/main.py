from fastapi import FastAPI, Query
from sqlalchemy import create_engine, text
import pandas as pd


app = FastAPI(
    title="Course Evaluation Insights API",
    description="API for accessing privacy-safe course evaluation insights.",
    version="1.1.0"
)

engine = create_engine(
    "Replace with your database url"
)


def dataframe_to_records(df: pd.DataFrame):
    return df.where(pd.notnull(df), None).to_dict(orient="records")


@app.get("/")
def root():
    return {
        "message": "Course Evaluation Insights API",
        "version": "1.1.0",
        "source": "PostgreSQL analytics views",
        "available_endpoints": [
            "/api/v1/health",
            "/api/v1/courses/performance",
            "/api/v1/instructors/performance",
            "/api/v1/departments/summary",
            "/api/v1/alerts/courses"
        ]
    }


@app.get("/api/v1/health")
def health_check():
    return {
        "status": "ok",
        "database": "course_eval_ai",
        "views_used": [
            "vw_course_performance",
            "vw_instructor_performance",
            "vw_department_performance",
            "vw_course_alerts"
        ]
    }


@app.get("/api/v1/courses/performance")
def get_course_performance(
    department: str | None = Query(default=None),
    college: str | None = Query(default=None),
    delivery_code: str | None = Query(default=None),
    risk_status: str | None = Query(default=None),
    min_response_count: int = Query(default=3, ge=1),
    limit: int = Query(default=20, ge=1, le=100)
):
    query = """
        SELECT
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
            avg_course_rating,
            avg_instructor_rating,
            rating_gap,
            response_count,
            course_rating_response_count,
            instructor_rating_response_count,
            instructor_count,
            course_rating_stddev,
            instructor_rating_stddev,
            course_rating_median,
            instructor_rating_median,
            department_avg_course_rating,
            department_avg_instructor_rating,
            course_vs_department_delta,
            instructor_vs_department_delta,
            risk_status
        FROM vw_course_performance
        WHERE response_count >= :min_response_count
    """

    params = {
        "min_response_count": min_response_count,
        "limit": limit
    }

    if department:
        query += ' AND "Department" = :department'
        params["department"] = department

    if college:
        query += ' AND "College" = :college'
        params["college"] = college

    if delivery_code:
        query += ' AND "DeliveryCode" = :delivery_code'
        params["delivery_code"] = delivery_code

    if risk_status:
        query += " AND risk_status = :risk_status"
        params["risk_status"] = risk_status

    query += """
        ORDER BY avg_course_rating ASC, response_count DESC
        LIMIT :limit
    """

    df = pd.read_sql(text(query), engine, params=params)
    return dataframe_to_records(df)


@app.get("/api/v1/instructors/performance")
def get_instructor_performance(
    department: str | None = Query(default=None),
    college: str | None = Query(default=None),
    risk_status: str | None = Query(default=None),
    min_response_count: int = Query(default=3, ge=1),
    limit: int = Query(default=20, ge=1, le=100)
):
    query = """
        SELECT
            "Instructor_alias",
            "Department",
            "College",
            avg_instructor_rating,
            avg_course_rating,
            rating_gap,
            response_count,
            course_count,
            instructor_rating_stddev,
            course_rating_stddev,
            instructor_rating_median,
            course_rating_median,
            department_avg_instructor_rating,
            department_avg_course_rating,
            instructor_vs_department_delta,
            course_vs_department_delta,
            instructor_percentile_in_department,
            risk_status
        FROM vw_instructor_performance
        WHERE response_count >= :min_response_count
    """

    params = {
        "min_response_count": min_response_count,
        "limit": limit
    }

    if department:
        query += ' AND "Department" = :department'
        params["department"] = department

    if college:
        query += ' AND "College" = :college'
        params["college"] = college

    if risk_status:
        query += " AND risk_status = :risk_status"
        params["risk_status"] = risk_status

    query += """
        ORDER BY avg_instructor_rating ASC, response_count DESC
        LIMIT :limit
    """

    df = pd.read_sql(text(query), engine, params=params)
    return dataframe_to_records(df)


@app.get("/api/v1/departments/summary")
def get_department_summary(
    college: str | None = Query(default=None),
    risk_status: str | None = Query(default=None),
    min_response_count: int = Query(default=3, ge=1),
    limit: int = Query(default=50, ge=1, le=100)
):
    query = """
        SELECT
            "Department",
            "College",
            avg_course_rating,
            avg_instructor_rating,
            rating_gap,
            response_count,
            course_count,
            instructor_count,
            course_rating_stddev,
            instructor_rating_stddev,
            course_rating_median,
            instructor_rating_median,
            risk_status
        FROM vw_department_performance
        WHERE response_count >= :min_response_count
    """

    params = {
        "min_response_count": min_response_count,
        "limit": limit
    }

    if college:
        query += ' AND "College" = :college'
        params["college"] = college

    if risk_status:
        query += " AND risk_status = :risk_status"
        params["risk_status"] = risk_status

    query += """
        ORDER BY avg_course_rating ASC, response_count DESC
        LIMIT :limit
    """

    df = pd.read_sql(text(query), engine, params=params)
    return dataframe_to_records(df)


@app.get("/api/v1/alerts/courses")
def get_course_alerts(
    department: str | None = Query(default=None),
    college: str | None = Query(default=None),
    delivery_code: str | None = Query(default=None),
    risk_status: str | None = Query(default=None),
    min_response_count: int = Query(default=1, ge=1),
    limit: int = Query(default=50, ge=1, le=100)
):
    query = """
        SELECT
            "CourseIdentifier",
            "CourseTitle",
            "Department",
            "College",
            "DeliveryCode",
            avg_course_rating,
            avg_instructor_rating,
            rating_gap,
            response_count,
            instructor_count,
            course_rating_stddev,
            instructor_rating_stddev,
            course_rating_median,
            instructor_rating_median,
            course_vs_department_delta,
            instructor_vs_department_delta,
            risk_status,
            alert_priority
        FROM vw_course_alerts
        WHERE response_count >= :min_response_count
    """

    params = {
        "min_response_count": min_response_count,
        "limit": limit
    }

    if department:
        query += ' AND "Department" = :department'
        params["department"] = department

    if college:
        query += ' AND "College" = :college'
        params["college"] = college

    if delivery_code:
        query += ' AND "DeliveryCode" = :delivery_code'
        params["delivery_code"] = delivery_code

    if risk_status:
        query += " AND risk_status = :risk_status"
        params["risk_status"] = risk_status

    query += """
        ORDER BY alert_priority DESC, avg_course_rating ASC, response_count DESC
        LIMIT :limit
    """

    df = pd.read_sql(text(query), engine, params=params)
    return dataframe_to_records(df)