## 1. How do I calculate instructor average?

Use the seven instructor questions: **i1 through i7**.

For each student response, average only the instructor questions the student actually answered. Then average those student-level instructor scores for each instructor alias.

**Example 1:**
A student gives: 5, 4, 5, 4, 5, 5, 4.
Instructor score for that response = **4.57**.

**Example 2:**
A student gives: 5, 4, 5, 4, 5, skipped, skipped.
Instructor score for that response = **4.60**, because only the five answered questions count.

---

## 2. How do I calculate course average?

Use the five course questions: **c1 through c5**.

For each student response, average only the course questions the student answered. Then average those student-level course scores for each course.

**Example 1:**
A student gives: 4, 4, 5, 5, 4.
Course score for that response = **4.40**.

**Example 2:**
A student gives: 5, 5, 5, skipped, skipped.
Course score for that response = **5.00**, because only the three answered questions count.

---

## 3. How do I handle NULL/skipped questions?

Skipped questions stay as **NULL**. They should not be converted to zero.

The average should be:

**sum of answered ratings ÷ number of answered ratings**

Not:

**sum of ratings ÷ total possible questions**

**Example 1:**
Ratings: 5, 5, skipped, 4, skipped.
Correct average = **4.67**.

**Example 2:**
If skipped values were treated as zero, the same response would become **2.80**. That is wrong because skipped answers are not negative feedback.

---

## 4. What is the minimum response count?

For the MVP, use a minimum response count of **3**.

But for real decision-making, be stricter:

| Response count | Meaning                  |
| -------------- | ------------------------ |
| 1–2            | Too small; do not rank   |
| 3–4            | Low confidence           |
| 5–9            | Usable, but with caution |
| 10+            | Stronger confidence      |

**Example 1:**
A course with 2 responses and a 4.9 average should not be treated as a top-performing course. The sample is too small.

**Example 2:**
A course with 25 responses and a 3.1 average is much more meaningful and should be reviewed.

---

## 5. How do I flag low-confidence results?

Flag results when the response count is too low or when students strongly disagree.

Use labels like:

| Label               | Meaning                                 |
| ------------------- | --------------------------------------- |
| Insufficient sample | Fewer than 3 responses                  |
| Low confidence      | 3–4 responses                           |
| Mixed feedback      | Enough responses, but high disagreement |
| Review              | Low average with enough responses       |
| OK                  | Enough responses and no major concern   |

**Example 1:**
Average rating = 4.8, response count = 2.
Flag = **Insufficient sample**.

**Example 2:**
Average rating = 3.5, response count = 20, but ratings are split between very low and very high.
Flag = **Mixed feedback**.

---

## 6. How do I show spread/disagreement?

Do not show only the average. Averages can hide disagreement.

Show:

| Metric              | Purpose                           |
| ------------------- | --------------------------------- |
| Average             | Overall score                     |
| Median              | Typical student experience        |
| Standard deviation  | How much students disagree        |
| Rating distribution | Percent of 1s, 2s, 3s, 4s, and 5s |
| Response count      | How much data supports the score  |

**Example 1:**
Ratings: 4, 4, 4, 5, 5.
Average is high and disagreement is low. Students mostly agree.

**Example 2:**
Ratings: 1, 2, 3, 5, 5.
Average looks moderate, but disagreement is high. Some students had a bad experience while others had a good one.

That second case needs more attention than the average alone suggests.

---

## 7. How do I normalize against department or college average?

Compare a course or instructor against its department or college average. This gives context.

Use this idea:

**normalized difference = item average − group average**

**Example 1:**
Course average = 4.2.
Department average = 3.8.
Difference = **+0.4**.
That course is performing above its department baseline.

**Example 2:**
Course average = 3.4.
Department average = 4.1.
Difference = **−0.7**.
That course is underperforming compared with similar courses.

This is better than only comparing every course to the whole university. A hard technical course, a writing-heavy course, and an online asynchronous course may have different rating patterns. Department and college normalization makes the comparison fairer.

## Clean final answer

| Question               | Answer                                                                          |
| ---------------------- | ------------------------------------------------------------------------------- |
| Instructor average     | Average i1–i7, skipping NULLs.                                                  |
| Course average         | Average c1–c5, skipping NULLs.                                                  |
| NULL/skipped questions | Keep as NULL; exclude from denominator.                                         |
| Minimum response count | Use 3 for MVP; prefer 5+ or 10+ for stronger decisions.                         |
| Low-confidence results | Flag low response counts and high disagreement.                                 |
| Spread/disagreement    | Show standard deviation, median, rating distribution, and response count.       |
| Normalization          | Compare against department and college averages using positive/negative deltas. |
