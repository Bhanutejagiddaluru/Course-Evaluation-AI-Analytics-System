from pathlib import Path
from sqlalchemy import create_engine, text

DATABASE_URL = "postgresql://postgres:admin@localhost:5432/course_eval_ai"

PROJECT_ROOT = Path(__file__).resolve().parents[2]
VIEWS_DIR = PROJECT_ROOT / "database" / "views"

engine = create_engine(DATABASE_URL)

view_files = [
    "vw_bronze_row_scores.sql",
    "vw_course_performance.sql",
    "vw_instructor_performance.sql",
    "vw_department_performance.sql",
    "vw_college_performance.sql",
    "vw_course_alerts.sql",
]

with engine.begin() as conn:
    for file_name in view_files:
        file_path = VIEWS_DIR / file_name

        if not file_path.exists():
            print(f"SKIPPED: {file_name} not found")
            continue

        sql = file_path.read_text(encoding="utf-8").strip()

        if not sql:
            print(f"SKIPPED: {file_name} is empty")
            continue

        print(f"Running: {file_name}")
        conn.execute(text(sql))

print("All SQL views created successfully.")