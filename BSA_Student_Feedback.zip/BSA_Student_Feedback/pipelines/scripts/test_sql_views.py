import pandas as pd
from sqlalchemy import create_engine

DATABASE_URL = "postgresql://postgres:admin@localhost:5432/course_eval_ai"

engine = create_engine(DATABASE_URL)

views = [
    "vw_bronze_row_scores",
    "vw_course_performance",
    "vw_instructor_performance",
    "vw_department_performance",
    "vw_course_alerts",
]

for view in views:
    print("\n" + "=" * 80)
    print(f"Testing: {view}")
    df = pd.read_sql(f"SELECT * FROM {view} LIMIT 5", engine)
    print(df)